﻿using LibraryLayerObjects;
using System.Data;

namespace LibraryBusiness
{
    public interface IDatabase
    {
        bool InsertNewPerson(Person newPerson);

        bool InsertNewItem(Item newItem);

        bool CreateRequest(Request newRequest);

        List<Request> GetRequests(Guid personID);

        List<Review> GetReviews(Guid bookID);

        bool DeleteUser(Person p);
        
        Person GetPerson(string username);

        Person GetPerson(Guid ID);

        Review GetReview(Guid ID);

        List<Item> GetItems();

        List<Person> GetAllPersons();

        Role? GetRoleByID(Guid guid);

        bool UpdateUser(Person person);

        bool UpdateUserPassword(Person person);

        Item GetItemByID(Guid id);

        bool CreateReview(Review review);

        List<Item> GetTop3Requests();

        List<Request> GetAllRequests();

        bool UpdateRequest(Request request);

        bool AlterItem(Item item);

        bool AlterReview(Review review);
        bool DeleteReview(Review review);
    }
}
