﻿using LibraryLayerObjects;
using System.Data;
using System.Data.SqlClient;
using Request = LibraryLayerObjects.Request;

namespace LibraryBusiness
{
    public class DatabaseInstance : IDatabase
    {
        public bool InsertNewPerson(Person newPerson)
        {
            try
            {

                string sql = $@"
                        INSERT INTO PERSON (UserName,Name, SurName, Address, Password, RoleID) VALUES
                        ('{newPerson.Username}','{newPerson.Name}', '{newPerson.SurName}', '{newPerson.Address}','{newPerson.Password}', '{newPerson.Role.ID}')
                    ";

                return ExecuteNonScalarSQL(sql);
            }
            catch
            {
                return false;
            }

        }
        public bool InsertNewItem(Item newItem)
        {
            try
            {
                if (newItem is EBook)
                {

                    string sql = $@"
                        INSERT INTO Item (Title, Author, Publisher, Description, Genre, DPI,Type) VALUES
                        ('{newItem.Title}', '{newItem.Author}', '{newItem.Publisher}','{newItem.Description}','{newItem.Genre}','{((EBook)newItem).DPI}','2')
                    ";
                    return ExecuteNonScalarSQL(sql);
                }
                if (newItem is DVD)
                {

                    string sql = $@"
                        INSERT INTO Item (Title, Author, Publisher, Description, Genre, Minutes,Type) VALUES
                        ('{newItem.Title}', '{newItem.Author}', '{newItem.Publisher}','{newItem.Description}','{newItem.Genre}','{((DVD)newItem).Minutes}','3')
                    ";
                    return ExecuteNonScalarSQL(sql);
                }
                if (newItem is Book)
                {

                    string sql = $@"
                        INSERT INTO Item (Title, Author, Publisher, Description, Genre, Pages,Type) VALUES
                        ('{newItem.Title}', '{newItem.Author}', '{newItem.Publisher}','{newItem.Description}', '{newItem.Genre}' , '{((Book)newItem).Pages}','1')
                    ";

                    return ExecuteNonScalarSQL(sql);
                }

            }
            catch (Exception ex)
            {
                throw;
            }
            return false;
        }
        public bool CreateRequest(Request newRequest)
        {
            try
            {
                string sql = $@"
                     INSERT INTO PersonRentedItems (PersonID,BookID,Quantity,Accepted) VALUES
                     ('{newRequest.PersonID}','{newRequest.BookID}','{newRequest.Quantity}',null)
                     ";

                return ExecuteNonScalarSQL(sql);

            }
            catch (Exception ex)
            {
                return false;
                throw;
            }
        }
        public List<Request> GetRequests(Guid personID)
        {
            List<Request> requests = new();
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM PersonRentedItems where PersonID = @personID and Accepted is not null", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@PersonID", personID));
                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    Request request = new();
                    request.ID = (Guid)reader["ID"];
                    request.BookID = (Guid)reader["BookID"];
                    request.Accepted = (bool)reader["Accepted"];
                    request.Quantity = (int)reader["Quantity"];
                    requests.Add(request);
                }

            }
            catch (Exception ex)
            {
                throw;
            }
            return requests;
        }
        public List<Review> GetReviews(Guid bookID)
        {
            List<Review> reviews = new();
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM Reviews where BookID=@BookID", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@BookID", bookID));
                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    Review review = new();
                    review.ID = (Guid)reader["ID"];
                    review.BookID = (Guid)reader["BookID"];
                    review.PersonID = (Guid)reader["PersonID"];
                    review.ReviewText = (string)reader["Review"];
                    reviews.Add(review);
                }

            }
            catch (Exception ex)
            {
                throw;
            }
            return reviews;
        }
        public bool DeleteUser(Person p)
        {
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                string sql = $@"DELETE FROM Person where UserName=@UserName";
                SqlCommand sqlCommand = new(sql, conn);
                sqlCommand.Parameters.AddWithValue("@UserName", p.Username);

                sqlCommand.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
                throw;
            }

        }
        public bool DeleteReview(Review r)
        {
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                string sql = $@"DELETE Reviews  where ID=@ID";
                SqlCommand sqlCommand = new(sql, conn);
                sqlCommand.Parameters.AddWithValue("@ID", r.ID);

                sqlCommand.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
                throw;
            }

        }

        private bool ExecuteNonScalarSQL(string sql)
        {
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");

            try
            {
                conn.Open();
                return new SqlCommand(sql, conn).ExecuteNonQuery() != 0;
            }
            catch (SqlException exception)
            {
                return false;
                throw new InvalidOperationException("Data could not be read", exception);
            }
            catch (NullReferenceException nullException)
            {
                throw new NullReferenceException("There is not a valid object.");
            }
            catch (OutOfMemoryException outOfMemoryException)
            {
                throw new OutOfMemoryException("Application is out of memory.");
            }
            catch (InvalidCastException invalidCastException)
            {
                throw new OutOfMemoryException("Casting thid object was not successfull.");
            }
            catch (Exception ex)
            {
                return false;
                throw;
            }
            finally { conn.Close(); }
        }

        public Person GetPerson(string username)
        {
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM PERSON WHERE USERNAME = @Username", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@Username", username));
                SqlDataReader reader = sqlCommand.ExecuteReader();
                Person person = new();
                while (reader.Read())
                {
                    person.ID = (Guid)reader["ID"];
                    person.Username = (string)reader["UserName"];
                    person.Name = (string)reader["Name"];
                    person.Password = (string)reader["Password"];
                    person.SurName = (string)reader["SurName"];
                    person.Address = (string)reader["Address"];
                    person.Role = GetRoleByID((Guid)reader["RoleID"]) ?? throw new ArgumentNullException("No Role for specified user");

                }
                return person;

            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        public Person GetPerson(Guid ID)
        {
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM Person where ID = @ID", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@ID", ID));
                SqlDataReader reader = sqlCommand.ExecuteReader();
                Person person = new();
                while (reader.Read())
                {
                    person.ID = (Guid)reader["ID"];
                    person.Username = (string)reader["UserName"];
                    person.Name = (string)reader["Name"];
                    person.SurName = (string)reader["SurName"];
                    person.Address = (string)reader["Address"];
                    person.Role = GetRoleByID((Guid)reader["RoleID"]) ?? throw new ArgumentNullException("No Role for specified user");

                }
                return person;

            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
        }
        public Review GetReview(Guid ID)
        {
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM Reviews where ID = @ID", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@ID", ID));
                SqlDataReader reader = sqlCommand.ExecuteReader();
                Review review = new();
                while (reader.Read())
                {
                    review.ID = (Guid)reader["ID"];
                    review.PersonID = (Guid)reader["PersonID"];
                    review.BookID = (Guid)reader["BookID"];
                    review.ReviewText = (string)reader["Review"];
                }
                return review;

            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
        }
        public List<Item> GetItems()
        {
            List<Item> items = new();
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM Item ", conn);
                Item item;

                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    int type = (int)reader["Type"];
                    switch (type)
                    {
                        case 1:
                            item = new Book();
                            ((Book)item).Pages = (int)reader["Pages"];
                            break;
                        case 3:
                            item = new DVD();
                            ((DVD)item).Minutes = (int)reader["minutes"];
                            break;
                        case 2:
                            item = new EBook();
                            ((EBook)item).DPI = (int)reader["DPI"];
                            break;
                        default: throw new InvalidProgramException("Type is unknown");
                    }
                    item.Id = (Guid)reader["ID"];
                    item.Title = (string)reader["Title"];
                    item.Author = (string)reader["Author"];
                    item.Publisher = (string)reader["Publisher"];
                    item.Description = (string)reader["Description"];
                    item.Genre = (string)reader["Genre"];
                    items.Add(item);


                }
                return items;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally { conn.Close(); }


        }

        private DataTable ExecuteSQL(string sql)
        {
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                DataTable tab = new();
                conn.Open();
                using (SqlDataAdapter comm = new(sql, conn))
                {
                    // Adapter fill table function
                    comm.Fill(tab);
                }
                return tab;

            }
            catch (SqlException exception)
            {

                throw new InvalidOperationException("Data could not be read", exception);
            }
            catch (NullReferenceException nullException)
            {
                throw new NullReferenceException("There is not a valid object.");
            }
            catch (OutOfMemoryException outOfMemoryException)
            {
                throw new OutOfMemoryException("Application is out of memory.");
            }
            catch (InvalidCastException invalidCastException)
            {
                throw new OutOfMemoryException("Casting this object was not successfull.");
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        public List<Person> GetAllPersons()
        {
            List<Person> people = new();
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM Person", conn);
                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    Person person = new();
                    person.Name = (string)reader["Name"];
                    person.SurName = (string)reader["SurName"];
                    person.Address = (string)reader["Address"];
                    person.ID = (Guid)reader["ID"];
                    person.Role = GetRoleByID((Guid)reader["RoleID"]);
                    person.Role.ID = (Guid)reader["RoleID"];
                    person.Username = (string)reader["UserName"];


                    people.Add((person));
                }
                return people;

            }
            catch (Exception ex)
            {
                throw;
            }
            finally { conn.Close(); }

        }

        public Role? GetRoleByID(Guid guid)
        {
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM Roles where ID = @RoleID", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@RoleID", guid));
                SqlDataReader reader = sqlCommand.ExecuteReader();
                Role role = new();
                while (reader.Read())
                {
                    role.ID = (Guid)reader["ID"];
                    role.Name = (string)reader["Name"];
                    role.AccessLevel = (int)reader["AccessLevel"];
                }
                return role;

            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
        }
        public bool UpdateUser(Person person)
        {
            try
            {

                using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
                conn.Open();
                SqlCommand sqlCommand = new($@"UPDATE person
                                                                SET 
                                                                    UserName = @Username,
                                                                    Name = @Name,
                                                                    SurName = @SurName,
                                                                    Address = @Address,
                                                                    RoleID = @RoleID
                                                                WHERE ID = @ID ", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@ID", person.ID));
                sqlCommand.Parameters.Add(new SqlParameter("@Username", person.Username));
                sqlCommand.Parameters.Add(new SqlParameter("@Name", person.Name));
                sqlCommand.Parameters.Add(new SqlParameter("@SurName", person.SurName));
                sqlCommand.Parameters.Add(new SqlParameter("@Address", person.Address));
                sqlCommand.Parameters.Add(new SqlParameter("@RoleID", person.Role.ID));
                return sqlCommand.ExecuteNonQuery() != 0;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public bool UpdateUserPassword(Person person)
        {
            try
            {

                using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
                conn.Open();
                SqlCommand sqlCommand = new($@"UPDATE person
                                                                SET 
                                                                   Password=@Password
                                                                WHERE ID = @ID ", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@ID", person.ID));
                sqlCommand.Parameters.Add(new SqlParameter("@Password", person.Password));

                return sqlCommand.ExecuteNonQuery() != 0;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public Item GetItemByID(Guid id)
        {
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM Item where ID = @ItemID", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@ItemID", id));
                SqlDataReader reader = sqlCommand.ExecuteReader();
                Item item;

                while (reader.Read())
                {
                    int type = (int)reader["Type"];
                    switch (type)
                    {
                        case 1:
                            item = new Book();
                            ((Book)item).Pages = (int)reader["Pages"];
                            break;
                        case 2:
                            item = new DVD();
                            ((DVD)item).Minutes = (int)reader["minutes"];
                            break;
                        case 3:
                            item = new EBook();
                            ((EBook)item).DPI = (int)reader["DPI"];
                            break;
                        default: throw new InvalidProgramException("Type is unknown");
                    }
                    item.Id = (Guid)reader["ID"];
                    item.Title = (string)reader["Title"];
                    item.Author = (string)reader["Author"];
                    item.Publisher = (string)reader["Publisher"];
                    item.Description = (string)reader["Description"];
                    item.Genre = (string)reader["Genre"];
                    return item;
                }

            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public bool CreateReview(Review review)
        {
            try
            {
                string sql = $@"
                     INSERT INTO Reviews (PersonID,BookID,Review) VALUES
                     ('{review.PersonID}','{review.BookID}','{review.ReviewText}')
                     ";

                return ExecuteNonScalarSQL(sql);

            }
            catch (Exception ex)
            {
                throw;
            }
            return false;
        }

        public List<Item> GetTop3Requests()
        {
            List<Item> items = new();
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT TOP 3 SUM(Quantity) as Quantity,BookID FROM PersonRentedItems GROUP BY BookID ", conn);
                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    Guid ID = (Guid)reader["BookID"];
                    int Quantity = (int)reader["Quantity"];

                    Item item = GetItemByID(ID);

                    items.Add((item));
                }
                return items;

            }
            catch (Exception ex)
            {
                throw;
            }
            finally { conn.Close(); }
        }

        public List<Request> GetAllRequests()
        {
            List<Request> requests = new();
            using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
            try
            {
                conn.Open();
                SqlCommand sqlCommand = new($@"SELECT * FROM PersonRentedItems", conn);
                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                {
                    Request request = new();
                    request.ID = (Guid)reader["ID"];
                    request.PersonID = (Guid)reader["PersonID"];
                    request.BookID = (Guid)reader["BookID"];
                    request.Quantity = (int)reader["Quantity"];
                    if (DBNull.Value.Equals(reader["Accepted"]))
                    {
                        request.Accepted = false;
                    }
                    else if (!DBNull.Value.Equals(reader["Accepted"]))
                    {
                        request.Accepted = (bool)reader["Accepted"];

                    }

                    requests.Add((request));
                }
                return requests;

            }
            catch (Exception ex)
            {
                throw;
            }
            finally { conn.Close(); }

        }

        public bool UpdateRequest(Request request)
        {
            try
            {

                using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
                conn.Open();
                SqlCommand sqlCommand = new($@"UPDATE PersonRentedItems
                                                                SET 
                                                                    Accepted=@Accepted
                                                                WHERE ID = @ID ", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@ID", request.ID));
                sqlCommand.Parameters.Add(new SqlParameter("@Accepted", request.Accepted));

                return sqlCommand.ExecuteNonQuery() != 0;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public bool AlterItem(Item item)
        {
            try
            {

                using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
                conn.Open();
                SqlCommand sqlCommand = new($@"UPDATE Item
                                                                SET 
                                                                    Title = @Title,
                                                                    Author = @Author,
                                                                    Publisher = @Publisher,
                                                                    Genre = @Genre,
                                                                    Description = @Description
                                                                    
                                                                WHERE ID = @ID ", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@ID", item.Id));
                sqlCommand.Parameters.Add(new SqlParameter("@Title", item.Title));
                sqlCommand.Parameters.Add(new SqlParameter("@Genre", item.Genre));

                sqlCommand.Parameters.Add(new SqlParameter("@Author", item.Author));
                sqlCommand.Parameters.Add(new SqlParameter("@Publisher", item.Publisher));
                sqlCommand.Parameters.Add(new SqlParameter("@Description", item.Description));
                return sqlCommand.ExecuteNonQuery() != 0;
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public bool AlterReview(Review review)
        {
            try
            {

                using SqlConnection conn = new(@"Server=mssqlstud.fhict.local;Database=dbi477507_library;User Id=dbi477507_library;Password=library123;");
                conn.Open();
                SqlCommand sqlCommand = new($@"UPDATE Reviews
                                                                SET 
                                                                    Review=@Review
                                                                WHERE ID = @ID ", conn);
                sqlCommand.Parameters.Add(new SqlParameter("@ID", review.ID));
                sqlCommand.Parameters.Add(new SqlParameter("@Review", review.ReviewText));

                return sqlCommand.ExecuteNonQuery() != 0;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
