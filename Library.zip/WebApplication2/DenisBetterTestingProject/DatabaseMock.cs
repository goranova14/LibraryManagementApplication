﻿using LibraryBusiness;
using LibraryLayerObjects;
using System;
using System.Data;

namespace DenisBetterTestingProject
{
    internal class DatabaseMock : IDatabase
    {
        #region People

        private List<Person> People { get; set; } = new List<Person>();
        private List<Item> Items { get; set; } = new List<Item>();
        public bool InsertNewPerson(Person newPerson)
        {
            People.Add(newPerson);
            return newPerson != null;
        }
        public bool UpdateUser(Person person)
        {
            if (People.FirstOrDefault(x => x.ID == person.ID) is Person original)
            {
                People.Remove(original);
                People.Add(person);
                return true;
            }
            return false;
        }

        public bool UpdateUserPassword(Person person)
        {
            if (People.FirstOrDefault(x => x.ID == person.ID) is Person original)
            {
                original.Password = person.Password;
                return true;
            }
            return false;
        }
        public bool DeleteUser(Person p)
        {
            return true;
        }
        public Role? GetRoleByID(Guid guid)
        {
            return new Role()
            {
                Name = "Deni",
                ID = guid,
                AccessLevel = 100
            };
        }

        public List<Person> GetAllPersons()
        {
            return new List<Person>()
            {
                new Person()
                {
                    Name = "Big Deni",
                    Username = "TheDeniMaister",
                    Address="Kozloduy",
                    SurName="Pipi"
                },
                new Person()
                {
                    Name = "Ivan",
                    Username = "Ivan"
                }
            };
        }
        public Person GetPerson(string username)
        {
            return People.Find(x => x.Username == username);
        }

        public Person GetPerson(Guid ID)
        {
            return People.FirstOrDefault(x => x.ID == ID);
        }

        #endregion

        #region Item
        public bool AlterItem(Item item)
        {
            if (Items.FirstOrDefault(x => x.Id == item.Id) is Item original)
            {
                Items.Remove(original);
                Items.Add(item);
                return true;
            }
            return false;
        }
        public Item GetItemByID(Guid id)
        {
            return Items.FirstOrDefault(x => x.Id == id);

        }

        public List<Item> GetItems()
        {
            return new List<Item>()
            {
                new Book()
                {
                    Title = "Biggg",
                    Author = "Deni",
                    Pages=212,
                    Description="Pipi",
                    Genre="Horror",
                    Publisher="Peter"
                },
                new Book()
                {
                    Title = "Small",
                    Author = "Item"
                }
            };
        }

        public bool InsertNewItem(Item newItem)
        {
            Items.Add(newItem);
            return newItem != null;
        }

        bool IDatabase.CreateRequest(Request newRequest)
        {
            throw new NotImplementedException();
        }

        List<Request> IDatabase.GetRequests(Guid personID)
        {
            throw new NotImplementedException();
        }

        List<Review> IDatabase.GetReviews(Guid bookID)
        {
            throw new NotImplementedException();
        }

        Review IDatabase.GetReview(Guid ID)
        {
            throw new NotImplementedException();
        }

        bool IDatabase.CreateReview(Review review)
        {
            throw new NotImplementedException();
        }

        List<Item> IDatabase.GetTop3Requests()
        {
            throw new NotImplementedException();
        }

        List<Request> IDatabase.GetAllRequests()
        {
            throw new NotImplementedException();
        }

        bool IDatabase.UpdateRequest(Request request)
        {
            throw new NotImplementedException();
        }

        bool IDatabase.AlterReview(Review review)
        {
            throw new NotImplementedException();
        }

        bool IDatabase.DeleteReview(Review review)
        {
            throw new NotImplementedException();
        }
        #endregion




    }
}