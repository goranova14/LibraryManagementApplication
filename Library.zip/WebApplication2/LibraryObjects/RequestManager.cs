﻿using LibraryBusiness;
using LibraryLayerObjects;

namespace LibraryLayer
{
    public class RequestManager : ManagerBase, IRequestManager
    {
        public RequestManager(IDatabase database) : base(database)
        {

        }
        public List<Request> GetRequests(Guid personID)
        {
            return Database.GetRequests(personID);
        }

        public List<Request> GetAllRequests()
        {
            return Database.GetAllRequests();
        }
        public bool CreateRequest(Request request)
        {
            return Database.CreateRequest(request);
        }

        public bool UpdateRequest(Request request)
        {
            return Database.UpdateRequest(request);
        }
    }
}
