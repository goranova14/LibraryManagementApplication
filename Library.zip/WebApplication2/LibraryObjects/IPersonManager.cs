﻿using LibraryLayerObjects;

namespace LibraryLayer
{
    public interface IPersonManager
    {
        bool AddUser(Person person);
        bool DeleteUser(Person person);
        bool EditUser(Person person);
        bool EditUserPassword(Person person);
        List<Person> GetAll();
        Person GetPerson(Guid ID);
        Person Login(string username, string password);
    }
}