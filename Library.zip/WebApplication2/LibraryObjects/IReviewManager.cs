﻿using LibraryLayerObjects;

namespace LibraryLayer
{
    public interface IReviewManager
    {
        bool AddReview(Review review);
        bool AlterReview(Review review);
        bool DeleteReview(Review review);
        Review GetReview(Guid id);
        List<Review> GetReviews(Guid bookID);
    }
}