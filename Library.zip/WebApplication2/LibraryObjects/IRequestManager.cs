﻿using LibraryLayerObjects;

namespace LibraryLayer
{
    public interface IRequestManager
    {
        bool CreateRequest(Request request);
        List<Request> GetAllRequests();
        List<Request> GetRequests(Guid personID);
        bool UpdateRequest(Request request);

    }
}
