﻿using LibraryBusiness;

namespace LibraryLayer
{
    public class LibraryContainer
    {
        private IDatabase Database { get; }

        private Dictionary<Type, Func<object>> RegisteredContainers { get; } = new Dictionary<Type, Func<object>>();

        public LibraryContainer(IDatabase database)
        {
            Database = database;
            RegisterAsSingleton<IDatabase>(Database);
        }


        public void Register<Tin, Tout>()//Tin=interface, tout=exit value
        {
            RegisteredContainers.Add(typeof(Tin), () => { return CreateInstance(typeof(Tout)); });
        }

        public void RegisterAsSingleton<Tin>(object singleton)
        {
            RegisteredContainers.Add(typeof(Tin), () => { return singleton; });
        }

        private object CreateInstance(Type instanceAbleType)
        {
            return Activator.CreateInstance(instanceAbleType, Database);
        }

        public T GetInstance<T>()
        {
            Type t = typeof(T);
            if (RegisteredContainers.ContainsKey(t))
            {
                return (T)RegisteredContainers[t]();
            }
            return (T)CreateInstance(t);
        }
    }
}
