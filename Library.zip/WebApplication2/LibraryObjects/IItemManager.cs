﻿using LibraryLayerObjects;

namespace LibraryLayer
{
    public interface IItemManager
    {
       bool CreateItem(Item item);
        List<Item> GetItems();
        Item GetItemByID(Guid id);

        List<Item> GetTop3Requested();

        bool AlterItem(Item item);


    }
}
