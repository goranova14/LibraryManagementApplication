﻿using LibraryBusiness;
using LibraryLayerObjects;
using System.Data;

namespace LibraryLayer
{
    public class PersonManager : ManagerBase, IPersonManager
    {
        public PersonManager(IDatabase database) : base(database)
        {

        }

        public Person Login(string username, string password)
        {
            try
            {
                if (Database.GetPerson(username) is Person p)
                {
                    if (BCrypt.Net.BCrypt.Verify(password, p.Password))
                    {
                        return p;
                    }
                    return null;
                }

            }
            catch (Exception)
            {

            }
            return null;

        }

        public bool AddUser(Person person)
        {
            if (person is null)
                return false;
            person.Password = BCrypt.Net.BCrypt.HashPassword(person.Password);
            return Database.InsertNewPerson(person);
        }

        public bool DeleteUser(Person person)
        {
            return Database.DeleteUser(person);
        }

        public bool EditUser(Person person)
        {
            return Database.UpdateUser(person);
        }
        
        public bool EditUserPassword(Person person)
        {
            return Database.UpdateUserPassword(person);
        }

        public Person GetPerson(Guid ID)
        {
            return Database.GetPerson(ID);
        }


        public List<Person> GetAll()
        {
            return Database.GetAllPersons();
        }
    }
}
