﻿namespace DenisTestProjectForTesting
{
    public class PersonManagerTests
    {
    }
}
