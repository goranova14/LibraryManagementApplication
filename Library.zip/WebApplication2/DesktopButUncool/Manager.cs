﻿using LibraryLayer;
using LibraryLayerObjects;
using System.Data;
using WebApplication2;

namespace DesktopButUncool
{
    public partial class Manager : Form
    {
        private List<Request> Requests;
        public Manager()
        {
            InitializeComponent();
            Requests = new List<Request>();

        }
        private Person Person { get; set; }

        private void lvPeople_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lvPeople.SelectedItems)
            {
                Person = Provider.Container.GetInstance<IPersonManager>().GetAll().First(x => x.ID.ToString() == item.Text.ToString());
                tbFirstName.Text = Person.Name;
                tbLastName.Text = Person.SurName;
                tbAddress.Text = Person.Address;
                tbUsername.Text = Person.Username;
            }
        }

        private void Manager_Load(object sender, EventArgs e)
        {
            Requests = Provider.Container.GetInstance<IRequestManager>().GetAllRequests();
            try
            {
                lvPeople.View = View.Details;
                lvPeople.FullRowSelect = true;
                lvPeople.Columns.Add(new ColumnHeader() { Width = 0, Text = "ID" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Deni's favorite people" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Name" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Surname" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Address" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Role" });

                List<Item> Items = Provider.Container.GetInstance<IItemManager>().GetTop3Requested();
                Item i = Items.First();
                lblFirstPlaced.Text = i.Title;
                lblSecondPlaced.Text = Items[1].Title;
                 lblThirdPlace.Text = Items[2].Title;

                pbRequests.Maximum = Requests.Count;
                Requests = Requests.Where(x => x.Accepted == true).ToList();
                int countAccepted = Requests.Count;
                pbRequests.Value = countAccepted;
                UpdateListView();


            }
            catch
            {

            }
        }
        private void UpdateListView()
        {
            lvPeople.Items.Clear();

            foreach (Person person in Provider.Container.GetInstance<IPersonManager>().GetAll())
            {
                if (person.Role.Name == "Admin")
                {

                    lvPeople.Items.Add(new ListViewItem(new String[] { person.ID.ToString(), person.Username, person.Name, person.SurName, person.Address, person.Role.Name, person.Role.ToString(), person.Role.ID.ToString() }));
                }
            }

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Person.Name = tbFirstName.Text;
            Person.SurName = tbLastName.Text;
            Person.Address = tbAddress.Text;
            Person.Username = tbUsername.Text;
            switch (cbRole.SelectedIndex)
            {
                case 0:
                    Person.Role = new Role()
                    {
                        ID = new Guid("5EB66051-FB47-4A9A-ADBA-E3A56BDB8F18")//regular user ID

                    };
                    break;
                case 1:
                    Person.Role = new Role()
                    {
                        ID = new Guid("6FD29C8F-0532-469C-99BB-9EEE6EA9737C")//regular user ID
                    };
                    break;
                default:
                    break;
            }
            Provider.Container.GetInstance<IPersonManager>().EditUser(Person);
            UpdateListView();
        }

        private void cbSortByAdmins_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<Person> people = Provider.Container.GetInstance<IPersonManager>().GetAll();
            people = people.Where(x => x.Role.Name == "Admin").ToList();
            lvPeople.Items.Clear();
            switch (cbSortByAdmins.SelectedIndex)
            {
                case 0:
                    people.Sort((a, b) => a.Name.CompareTo(b.Name));
                    break;
                case 1:
                    people.Sort((a, b) => b.Name.CompareTo(a.Name));
                    break;
                case 2:
                    people = people.Where(x => x.Role.Name == "Admin").ToList();
                    break;
                case 3:
                    people = people.Where(x => x.Role.Name == "Client").ToList();
                    break;
                default:
                    break;
            }
            foreach (Person person in people)
            {
                lvPeople.Items.Add(new ListViewItem(new String[] { person.ID.ToString(), person.Username, person.Name, person.SurName, person.Address, person.Role.Name, person.Role.ToString(), person.Role.ID.ToString() }));
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            List<Person> people = Provider.Container.GetInstance<IPersonManager>().GetAll();
            people = people.Where(x => x.Role.Name == "Admin").ToList();

            lvPeople.Items.Clear();
            string username = tbSearchAdmin.Text;
            people = people.Where(x => x.Username.ToLower().Contains(username.ToLower())).ToList();
            foreach (Person person in people)
            {
                lvPeople.Items.Add(new ListViewItem(new String[] { person.ID.ToString(), person.Username, person.Name, person.SurName, person.Address, person.Role.Name, person.Role.ToString(), person.Role.ID.ToString() }));
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Login login = new();
            login.Show();
        }

       
    }
}
