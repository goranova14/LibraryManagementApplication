﻿namespace DesktopButUncool
{
	partial class Manager
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manager));
            this.tcAdmin = new System.Windows.Forms.TabControl();
            this.tpHome = new System.Windows.Forms.TabPage();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.tpAdmins = new System.Windows.Forms.TabPage();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblSearchAdmin = new System.Windows.Forms.Label();
            this.tbSearchAdmin = new System.Windows.Forms.TextBox();
            this.lblOrderAdmins = new System.Windows.Forms.Label();
            this.gbEditInfo = new System.Windows.Forms.GroupBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.cbRole = new System.Windows.Forms.ComboBox();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.btnEdit = new System.Windows.Forms.Button();
            this.tbAddress = new System.Windows.Forms.TextBox();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbSortByAdmins = new System.Windows.Forms.ComboBox();
            this.lvPeople = new System.Windows.Forms.ListView();
            this.tpStatistics = new System.Windows.Forms.TabPage();
            this.gbRankedBooks = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblThirdPlace = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblSecondPlaced = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblFirstPlaced = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.gbRequests = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pbRequests = new System.Windows.Forms.ProgressBar();
            this.label11 = new System.Windows.Forms.Label();
            this.tcAdmin.SuspendLayout();
            this.tpHome.SuspendLayout();
            this.tpAdmins.SuspendLayout();
            this.gbEditInfo.SuspendLayout();
            this.tpStatistics.SuspendLayout();
            this.gbRankedBooks.SuspendLayout();
            this.gbRequests.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcAdmin
            // 
            this.tcAdmin.Controls.Add(this.tpHome);
            this.tcAdmin.Controls.Add(this.tpAdmins);
            this.tcAdmin.Controls.Add(this.tpStatistics);
            this.tcAdmin.Location = new System.Drawing.Point(12, 12);
            this.tcAdmin.Name = "tcAdmin";
            this.tcAdmin.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tcAdmin.SelectedIndex = 0;
            this.tcAdmin.Size = new System.Drawing.Size(1408, 734);
            this.tcAdmin.TabIndex = 1;
            // 
            // tpHome
            // 
            this.tpHome.BackColor = System.Drawing.Color.LightGray;
            this.tpHome.Controls.Add(this.label11);
            this.tpHome.Controls.Add(this.btnLogout);
            this.tpHome.Controls.Add(this.lblWelcome);
            this.tpHome.Location = new System.Drawing.Point(4, 29);
            this.tpHome.Name = "tpHome";
            this.tpHome.Padding = new System.Windows.Forms.Padding(3);
            this.tpHome.Size = new System.Drawing.Size(1400, 701);
            this.tpHome.TabIndex = 0;
            this.tpHome.Text = "Home";
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Snow;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLogout.Location = new System.Drawing.Point(1259, 616);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(103, 43);
            this.btnLogout.TabIndex = 2;
            this.btnLogout.Text = "Log out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Vladimir Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblWelcome.Location = new System.Drawing.Point(143, 32);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(1001, 73);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome to Student Library management system";
            // 
            // tpAdmins
            // 
            this.tpAdmins.BackColor = System.Drawing.Color.LightGray;
            this.tpAdmins.Controls.Add(this.btnSearch);
            this.tpAdmins.Controls.Add(this.lblSearchAdmin);
            this.tpAdmins.Controls.Add(this.tbSearchAdmin);
            this.tpAdmins.Controls.Add(this.lblOrderAdmins);
            this.tpAdmins.Controls.Add(this.gbEditInfo);
            this.tpAdmins.Controls.Add(this.cbSortByAdmins);
            this.tpAdmins.Controls.Add(this.lvPeople);
            this.tpAdmins.Location = new System.Drawing.Point(4, 29);
            this.tpAdmins.Name = "tpAdmins";
            this.tpAdmins.Size = new System.Drawing.Size(1400, 701);
            this.tpAdmins.TabIndex = 1;
            this.tpAdmins.Text = "People";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSearch.Location = new System.Drawing.Point(1282, 259);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(105, 37);
            this.btnSearch.TabIndex = 28;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblSearchAdmin
            // 
            this.lblSearchAdmin.AutoSize = true;
            this.lblSearchAdmin.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSearchAdmin.Location = new System.Drawing.Point(1224, 173);
            this.lblSearchAdmin.Name = "lblSearchAdmin";
            this.lblSearchAdmin.Size = new System.Drawing.Size(160, 50);
            this.lblSearchAdmin.TabIndex = 27;
            this.lblSearchAdmin.Text = "Search admin\r\n(Insert username)";
            // 
            // tbSearchAdmin
            // 
            this.tbSearchAdmin.Location = new System.Drawing.Point(1224, 226);
            this.tbSearchAdmin.Name = "tbSearchAdmin";
            this.tbSearchAdmin.Size = new System.Drawing.Size(163, 27);
            this.tbSearchAdmin.TabIndex = 26;
            // 
            // lblOrderAdmins
            // 
            this.lblOrderAdmins.AutoSize = true;
            this.lblOrderAdmins.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblOrderAdmins.Location = new System.Drawing.Point(1224, 14);
            this.lblOrderAdmins.Name = "lblOrderAdmins";
            this.lblOrderAdmins.Size = new System.Drawing.Size(77, 25);
            this.lblOrderAdmins.TabIndex = 25;
            this.lblOrderAdmins.Text = "Sort by:";
            // 
            // gbEditInfo
            // 
            this.gbEditInfo.Controls.Add(this.lblRole);
            this.gbEditInfo.Controls.Add(this.cbRole);
            this.gbEditInfo.Controls.Add(this.tbLastName);
            this.gbEditInfo.Controls.Add(this.tbFirstName);
            this.gbEditInfo.Controls.Add(this.btnEdit);
            this.gbEditInfo.Controls.Add(this.tbAddress);
            this.gbEditInfo.Controls.Add(this.tbUsername);
            this.gbEditInfo.Controls.Add(this.label5);
            this.gbEditInfo.Controls.Add(this.label2);
            this.gbEditInfo.Controls.Add(this.label4);
            this.gbEditInfo.Controls.Add(this.label3);
            this.gbEditInfo.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.gbEditInfo.Location = new System.Drawing.Point(26, 259);
            this.gbEditInfo.Name = "gbEditInfo";
            this.gbEditInfo.Size = new System.Drawing.Size(406, 428);
            this.gbEditInfo.TabIndex = 24;
            this.gbEditInfo.TabStop = false;
            this.gbEditInfo.Text = "Edit information";
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(12, 280);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(48, 23);
            this.lblRole.TabIndex = 16;
            this.lblRole.Text = "Role:";
            // 
            // cbRole
            // 
            this.cbRole.FormattingEnabled = true;
            this.cbRole.Items.AddRange(new object[] {
            "Admin ",
            "Client"});
            this.cbRole.Location = new System.Drawing.Point(94, 306);
            this.cbRole.Name = "cbRole";
            this.cbRole.Size = new System.Drawing.Size(159, 31);
            this.cbRole.TabIndex = 15;
            // 
            // tbLastName
            // 
            this.tbLastName.Location = new System.Drawing.Point(94, 112);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(159, 30);
            this.tbLastName.TabIndex = 6;
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(94, 47);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(159, 30);
            this.tbFirstName.TabIndex = 2;
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(157, 356);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(142, 56);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "Edit information";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // tbAddress
            // 
            this.tbAddress.Location = new System.Drawing.Point(95, 239);
            this.tbAddress.Name = "tbAddress";
            this.tbAddress.Size = new System.Drawing.Size(158, 30);
            this.tbAddress.TabIndex = 3;
            // 
            // tbUsername
            // 
            this.tbUsername.Location = new System.Drawing.Point(95, 179);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(158, 30);
            this.tbUsername.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 23);
            this.label5.TabIndex = 10;
            this.label5.Text = "City:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 23);
            this.label2.TabIndex = 7;
            this.label2.Text = "First name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 23);
            this.label4.TabIndex = 9;
            this.label4.Text = "Username:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 23);
            this.label3.TabIndex = 8;
            this.label3.Text = "Last name:";
            // 
            // cbSortByAdmins
            // 
            this.cbSortByAdmins.FormattingEnabled = true;
            this.cbSortByAdmins.Items.AddRange(new object[] {
            "Alphabetically(A-Z)",
            "Alphabetically(Z-A)"});
            this.cbSortByAdmins.Location = new System.Drawing.Point(1224, 49);
            this.cbSortByAdmins.Name = "cbSortByAdmins";
            this.cbSortByAdmins.Size = new System.Drawing.Size(151, 28);
            this.cbSortByAdmins.TabIndex = 23;
            this.cbSortByAdmins.SelectedIndexChanged += new System.EventHandler(this.cbSortByAdmins_SelectedIndexChanged);
            // 
            // lvPeople
            // 
            this.lvPeople.Location = new System.Drawing.Point(14, 14);
            this.lvPeople.Name = "lvPeople";
            this.lvPeople.Size = new System.Drawing.Size(1204, 229);
            this.lvPeople.TabIndex = 20;
            this.lvPeople.UseCompatibleStateImageBehavior = false;
            this.lvPeople.View = System.Windows.Forms.View.Details;
            this.lvPeople.SelectedIndexChanged += new System.EventHandler(this.lvPeople_SelectedIndexChanged);
            // 
            // tpStatistics
            // 
            this.tpStatistics.BackColor = System.Drawing.Color.PeachPuff;
            this.tpStatistics.Controls.Add(this.gbRankedBooks);
            this.tpStatistics.Controls.Add(this.gbRequests);
            this.tpStatistics.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tpStatistics.Location = new System.Drawing.Point(4, 29);
            this.tpStatistics.Name = "tpStatistics";
            this.tpStatistics.Size = new System.Drawing.Size(1400, 701);
            this.tpStatistics.TabIndex = 2;
            this.tpStatistics.Text = "Statistics";
            // 
            // gbRankedBooks
            // 
            this.gbRankedBooks.Controls.Add(this.label10);
            this.gbRankedBooks.Controls.Add(this.label1);
            this.gbRankedBooks.Controls.Add(this.lblThirdPlace);
            this.gbRankedBooks.Controls.Add(this.label6);
            this.gbRankedBooks.Controls.Add(this.lblSecondPlaced);
            this.gbRankedBooks.Controls.Add(this.label7);
            this.gbRankedBooks.Controls.Add(this.lblFirstPlaced);
            this.gbRankedBooks.Controls.Add(this.label8);
            this.gbRankedBooks.Controls.Add(this.label9);
            this.gbRankedBooks.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.gbRankedBooks.Location = new System.Drawing.Point(352, 30);
            this.gbRankedBooks.Name = "gbRankedBooks";
            this.gbRankedBooks.Size = new System.Drawing.Size(576, 286);
            this.gbRankedBooks.TabIndex = 13;
            this.gbRankedBooks.TabStop = false;
            this.gbRankedBooks.Text = "Top three requested books";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(390, 195);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(130, 23);
            this.label10.TabIndex = 6;
            this.label10.Text = "Third requested";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(97, 175);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "_____________";
            // 
            // lblThirdPlace
            // 
            this.lblThirdPlace.AutoSize = true;
            this.lblThirdPlace.Location = new System.Drawing.Point(424, 152);
            this.lblThirdPlace.Name = "lblThirdPlace";
            this.lblThirdPlace.Size = new System.Drawing.Size(0, 23);
            this.lblThirdPlace.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(233, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 23);
            this.label6.TabIndex = 2;
            this.label6.Text = "_________________";
            // 
            // lblSecondPlaced
            // 
            this.lblSecondPlaced.AutoSize = true;
            this.lblSecondPlaced.Location = new System.Drawing.Point(114, 152);
            this.lblSecondPlaced.Name = "lblSecondPlaced";
            this.lblSecondPlaced.Size = new System.Drawing.Size(0, 23);
            this.lblSecondPlaced.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(399, 175);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 23);
            this.label7.TabIndex = 3;
            this.label7.Text = "______________";
            // 
            // lblFirstPlaced
            // 
            this.lblFirstPlaced.AutoSize = true;
            this.lblFirstPlaced.Location = new System.Drawing.Point(255, 54);
            this.lblFirstPlaced.Name = "lblFirstPlaced";
            this.lblFirstPlaced.Size = new System.Drawing.Size(0, 23);
            this.lblFirstPlaced.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(238, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 23);
            this.label8.TabIndex = 4;
            this.label8.Text = "First requested";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(72, 195);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(147, 23);
            this.label9.TabIndex = 5;
            this.label9.Text = "Second requested";
            // 
            // gbRequests
            // 
            this.gbRequests.Controls.Add(this.label17);
            this.gbRequests.Controls.Add(this.label16);
            this.gbRequests.Controls.Add(this.label15);
            this.gbRequests.Controls.Add(this.label13);
            this.gbRequests.Controls.Add(this.pbRequests);
            this.gbRequests.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.gbRequests.Location = new System.Drawing.Point(403, 399);
            this.gbRequests.Name = "gbRequests";
            this.gbRequests.Size = new System.Drawing.Size(467, 217);
            this.gbRequests.TabIndex = 12;
            this.gbRequests.TabStop = false;
            this.gbRequests.Text = "Statistic of requests";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label17.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.label17.Location = new System.Drawing.Point(38, 171);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(62, 25);
            this.label17.TabIndex = 15;
            this.label17.Text = "kljuijol";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(109, 171);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 25);
            this.label16.TabIndex = 14;
            this.label16.Text = "Accepted";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(109, 120);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 25);
            this.label15.TabIndex = 13;
            this.label15.Text = "Declined";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label13.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label13.Location = new System.Drawing.Point(38, 120);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 25);
            this.label13.TabIndex = 12;
            this.label13.Text = "lkhjglk";
            // 
            // pbRequests
            // 
            this.pbRequests.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRequests.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pbRequests.Location = new System.Drawing.Point(66, 72);
            this.pbRequests.Name = "pbRequests";
            this.pbRequests.Size = new System.Drawing.Size(321, 29);
            this.pbRequests.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(288, 213);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(822, 248);
            this.label11.TabIndex = 3;
            this.label11.Text = resources.GetString("label11.Text");
            // 
            // Manager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1427, 774);
            this.Controls.Add(this.tcAdmin);
            this.Name = "Manager";
            this.Text = "Manager";
            this.Load += new System.EventHandler(this.Manager_Load);
            this.tcAdmin.ResumeLayout(false);
            this.tpHome.ResumeLayout(false);
            this.tpHome.PerformLayout();
            this.tpAdmins.ResumeLayout(false);
            this.tpAdmins.PerformLayout();
            this.gbEditInfo.ResumeLayout(false);
            this.gbEditInfo.PerformLayout();
            this.tpStatistics.ResumeLayout(false);
            this.gbRankedBooks.ResumeLayout(false);
            this.gbRankedBooks.PerformLayout();
            this.gbRequests.ResumeLayout(false);
            this.gbRequests.PerformLayout();
            this.ResumeLayout(false);

		}

		#endregion

		private TabControl tcAdmin;
		private TabPage tpHome;
		private Button btnLogout;
		private Label lblWelcome;
		private TabPage tpAdmins;
		private TabPage tpStatistics;
        private Label lblSearchAdmin;
        private TextBox tbSearchAdmin;
        private Label lblOrderAdmins;
        private GroupBox gbEditInfo;
        private Label lblRole;
        private ComboBox cbRole;
        private TextBox tbLastName;
        private TextBox tbFirstName;
        private Button btnEdit;
        private TextBox tbAddress;
        private TextBox tbUsername;
        private Label label5;
        private Label label2;
        private Label label4;
        private Label label3;
        private ComboBox cbSortByAdmins;
        private ListView lvPeople;
        private Button btnSearch;
        private Label label7;
        private Label label6;
        private Label label1;
        private GroupBox gbRequests;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label13;
        private ProgressBar pbRequests;
        private Label lblThirdPlace;
        private Label lblSecondPlaced;
        private Label lblFirstPlaced;
        private Label label10;
        private Label label9;
        private Label label8;
        private GroupBox gbRankedBooks;
        private Label label11;
    }
}