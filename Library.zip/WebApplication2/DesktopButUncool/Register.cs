using LibraryLayer;
using LibraryLayerObjects;
using System.Text.RegularExpressions;
using WebApplication2;

namespace DesktopButUncool
{
    public partial class Form1 : Form
    {
        private readonly PersonManager PersonManager;
        public Form1()
        {
            InitializeComponent();

        }

        private void CreateUser(object sender, EventArgs e)
        {

            List<Person> people = Provider.Container.GetInstance<IPersonManager>().GetAll();
            string username = txtUsername.Text;
            int matches = people.Where(p => username == p.Username).Count();

            if (matches == 0)
            {
                Role role = new();
                if (cbRole.SelectedIndex == 1)
                {
                    role.ID = new Guid("6FD29C8F-0532-469C-99BB-9EEE6EA9737C");///normal user
                }
                else if (cbRole.SelectedIndex == 0)
                {
                    role.ID = new Guid("5EB66051-FB47-4A9A-ADBA-E3A56BDB8F18");//admin

                }
                else if (cbRole.SelectedIndex == 2)
                {
                    role.ID = new Guid("F2C2585E-0821-4FA3-A4DD-24D02F1DFAC9");//manager

                }
                if (txtCity.Text!="" || txtPassword.Text!="" || txtSurname.Text!="" || txtUsername.Text!="")
                {
                    Regex regex = new Regex(@"[^a - z]");
                    if (!regex.IsMatch(txtCity.Text))
                    {
                        MessageBox.Show("Put valid data");
                    }
                Provider.Container.GetInstance<IPersonManager>().AddUser(new Person()
                {

                    Role = role,
                    Name = txtFirstName.Text,
                    Password = txtPassword.Text,
                    Username = txtUsername.Text,
                    SurName = txtSurname.Text,
                    Address = txtCity.Text,
                }
                
                );
                MessageBox.Show("Good jobby!!!");
                this.Close();
                }
                else
                {
                    MessageBox.Show("All data should be putted");
                }
            }
            else
            {
                MessageBox.Show("This username already exists");
            }
        }
    }
}