﻿using LibraryLayer;
using LibraryLayerObjects;
using WebApplication2;

namespace DesktopButUncool
{
    public partial class Menu : Form
    {
        private readonly ItemManager ItemManager;
        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            try
            {
                lvPeople.View = View.Details;
                lvPeople.FullRowSelect = true;
                lvPeople.Columns.Add(new ColumnHeader() { Width = 0, Text = "ID" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Deni's favorite people" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Name" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Surname" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Address" });
                lvPeople.Columns.Add(new ColumnHeader() { Width = 100, Text = "Role" });
                lvRequests.View = View.Details;
                lvRequests.FullRowSelect = true;
                lvRequests.Columns.Add(new ColumnHeader() { Width = 0, Text = "ID" });
                lvRequests.Columns.Add(new ColumnHeader() { Width = 100, Text = "PersonID" });
                lvRequests.Columns.Add(new ColumnHeader() { Width = 100, Text = "BookID" });
                lvRequests.Columns.Add(new ColumnHeader() { Width = 100, Text = "Quantity" });
                lvRequests.Columns.Add(new ColumnHeader() { Width = 100, Text = "Accepted" }); lvRequests.View = View.Details;
                lvItems.FullRowSelect = true;
                lvItems.Columns.Add(new ColumnHeader() { Width = 0, Text = "ID" });
                lvItems.Columns.Add(new ColumnHeader() { Width = 100, Text = "Title" });
                lvItems.Columns.Add(new ColumnHeader() { Width = 100, Text = "Author" });
                lvItems.Columns.Add(new ColumnHeader() { Width = 100, Text = "Publisher" });
                lvItems.Columns.Add(new ColumnHeader() { Width = 100, Text = "Genre" });
                UpdateListView();
            }
            catch
            {

            }
        }
        private void UpdateListView()
        {
            lvPeople.Items.Clear();
            lvRequests.Items.Clear();
            lvItems.Items.Clear();

            foreach (Person person in Provider.Container.GetInstance<IPersonManager>().GetAll())
            {
                if (person.Role.Name != "Manager")
                {

                    lvPeople.Items.Add(new ListViewItem(new String[] { person.ID.ToString(), person.Username, person.Name, person.SurName, person.Address, person.Role.Name, person.Role.ToString(), person.Role.ID.ToString() }));
                }
            }
            foreach (Request request in Provider.Container.GetInstance<IRequestManager>().GetAllRequests())
            {
                lvRequests.Items.Add(new ListViewItem(new String[] { request.ID.ToString(), request.PersonID.ToString(), request.BookID.ToString(), request.Quantity.ToString(), request.Accepted.ToString() }));
            }
            foreach (Item item in Provider.Container.GetInstance<IItemManager>().GetItems())
            {
                lvItems.Items.Add(new ListViewItem(new String[] { item.Id.ToString(), item.Title.ToString(), item.Author.ToString(), item.Publisher.ToString(), item.Genre.ToString() }));
            }
        }

        private Person Person { get; set; }
        public Request Request { get; set; }
        public Item Item { get; set; }
        private void lvRequests_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lvRequests.SelectedItems)
            {
                Request = Provider.Container.GetInstance<IRequestManager>().GetAllRequests().First(x => x.ID.ToString() == item.Text.ToString());
            }
            for (int i = 0; i < lvRequests.Items.Count; i++)
            {
                if (lvRequests.Items[i].SubItems[4].Text == "True")
                {
                    cbStatus.SelectedIndex = 0;
                }
                if (lvRequests.Items[i].SubItems[4].Text == "False")
                {
                    cbStatus.SelectedIndex = 1;
                }
                else
                {
                    cbStatus.SelectedIndex = -1;
                }
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lvPeople.SelectedItems)
            {
                Person = Provider.Container.GetInstance<IPersonManager>().GetAll().First(x => x.ID.ToString() == item.Text.ToString());
                tbFirstName.Text = Person.Name;
                tbLastName.Text = Person.SurName;
                tbAddress.Text = Person.Address;
                tbUsername.Text = Person.Username;
            }

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (lvPeople.SelectedItems.Count == 0)
            {
                MessageBox.Show("Select a person");
            }
            else
            {

                Person.Name = tbFirstName.Text;
                Person.SurName = tbLastName.Text;
                Person.Address = tbAddress.Text;
                Person.Username = tbUsername.Text;
                switch (cbRole.SelectedIndex)
                {
                    case 0:
                        Person.Role = new Role()
                        {
                            ID = new Guid("5EB66051-FB47-4A9A-ADBA-E3A56BDB8F18")//admin

                        };
                        break;
                    case 1:
                        Person.Role = new Role()
                        {
                            ID = new Guid("6FD29C8F-0532-469C-99BB-9EEE6EA9737C")//regular user ID
                        };
                        break;
                    default:
                        break;
                }
                Provider.Container.GetInstance<IPersonManager>().EditUser(Person);
                UpdateListView();
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Form1 form = new();
            form.Show();
            UpdateListView();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lvPeople.SelectedItems.Count==0)
            {
                MessageBox.Show("Select a person");
            }
            else
            {

            Provider.Container.GetInstance<IPersonManager>().DeleteUser(Person);
            UpdateListView();
            }
        }


        private void cbSortBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<Person> people = Provider.Container.GetInstance<IPersonManager>().GetAll();
            lvPeople.Items.Clear();
            switch (cbSortBy.SelectedIndex)
            {
                case 0:
                    people.Sort((a, b) => a.Name.CompareTo(b.Name));
                    break;
                case 1:
                    people.Sort((a, b) => b.Name.CompareTo(a.Name));
                    break;
                case 2:
                    people = people.Where(x => x.Role.Name == "Admin").ToList();
                    break;
                case 3:
                    people = people.Where(x => x.Role.Name == "Client").ToList();
                    break;
                default:
                    break;
            }
            foreach (Person person in people)
            {
                lvPeople.Items.Add(new ListViewItem(new String[] { person.ID.ToString(), person.Username, person.Name, person.SurName, person.Address, person.Role.Name, person.Role.ToString(), person.Role.ID.ToString() }));
            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            List<Person> people = Provider.Container.GetInstance<IPersonManager>().GetAll();
            lvPeople.Items.Clear();
            string username = tbSearchU.Text;
            people = people.Where(x => x.Username.ToLower().Contains(username.ToLower())).ToList();
            foreach (Person person in people)
            {
                lvPeople.Items.Add(new ListViewItem(new String[] { person.ID.ToString(), person.Username, person.Name, person.SurName, person.Address, person.Role.Name, person.Role.ToString(), person.Role.ID.ToString() }));
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Login login = new();
            login.Show();
        }

        private void btnSubmitStatus_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lvRequests.SelectedItems)
            {
                Request = Provider.Container.GetInstance<IRequestManager>().GetAllRequests().First(x => x.ID.ToString() == item.Text.ToString());

                if (lvRequests.SelectedItems.Count == 1)
                {

                    if (cbStatus.SelectedIndex == 1)
                    {
                        Request.Accepted = false;
                        Provider.Container.GetInstance<IRequestManager>().UpdateRequest(Request);
                    }
                    else if (cbStatus.SelectedIndex == 0)
                    {
                        Request.Accepted = true;
                        Provider.Container.GetInstance<IRequestManager>().UpdateRequest(Request);
                    }
                }
                else
                {
                    MessageBox.Show("Select an item");
                }
            }
            UpdateListView();
        }

   

        private void lvItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lvItems.SelectedItems)
            {
                Item = Provider.Container.GetInstance<IItemManager>().GetItems().First(x => x.Id.ToString() == item.Text.ToString());
                tbTitle.Text = Item.Title;
                tbAuthor.Text = Item.Author;
                tbPublisher.Text = Item.Publisher;
                rtbDescription.Text = Item.Description;
                switch (Item.Genre)
                {
                    case "Romance":
                        cbGenre.SelectedIndex = 2;
                        break;
                    case "Horror":
                        cbGenre.SelectedIndex = 0;
                        break;
                    case "Comedy":
                        cbGenre.SelectedIndex = 1;
                        break;
                    case "Fiction":
                        cbGenre.SelectedIndex = 3;
                        break;
                    case "Triller":
                        cbGenre.SelectedIndex = 4;
                        break;
                    case "Sci-fi":
                        cbGenre.SelectedIndex = 5;
                        break;
                    case "Cooking":
                        cbGenre.SelectedIndex = 6;
                        break;
                    case "Educational":
                        cbGenre.SelectedIndex = 7;
                        break;
                    default:
                        break;
                }
            }
        }

        private void btnEditInfo_Click(object sender, EventArgs e)
        {
            if (lvItems.SelectedItems.Count == 0)
            {
                MessageBox.Show("Select an item first");
            }
            else
            {

                Item.Publisher = tbPublisher.Text;
                Item.Author = tbAuthor.Text;
                Item.Description = rtbDescription.Text;
                Item.Title = tbTitle.Text;
                switch (cbGenre.SelectedIndex)
                {
                    case 0:
                        Item.Genre = "Horror";
                        break;
                    case 1:
                        Item.Genre = "Comedy";

                        break;
                    case 2:
                        Item.Genre = "Romance";

                        break;
                    case 3:
                        Item.Genre = "Fiction";

                        break;
                    case 4:
                        Item.Genre = "Triller";

                        break;
                    case 5:
                        Item.Genre = "Sci-fi";

                        break;
                    case 6:
                        Item.Genre = "Cooking";

                        break;
                    case 7:
                        Item.Genre = "Educational";

                        break;
                    default:
                        break;
                }
            Provider.Container.GetInstance<IItemManager>().AlterItem(Item);
            UpdateListView();
            }
        }

        private void cbSort_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<Item> item = Provider.Container.GetInstance<IItemManager>().GetItems();
            lvItems.Items.Clear();
            switch (cbSort.SelectedIndex)
            {
                case 0:
                    item.Sort((a, b) => a.Title.CompareTo(b.Title));
                    break;
                case 1:
                    item.Sort((a, b) => b.Title.CompareTo(a.Title));
                    break;
                case 2:
                    item = item.Where(x => x.Genre == "Horror").ToList();
                    break;
                case 3:
                    item = item.Where(x => x.Genre == "Comedy").ToList();
                    break;
                case 4:
                    item = item.Where(x => x.Genre == "Romance").ToList();
                    break;
                case 5:
                    item = item.Where(x => x.Genre == "Fiction").ToList();
                    break;
                case 6:
                    item = item.Where(x => x.Genre == "Triller").ToList();
                    break;
                case 7:
                    item = item.Where(x => x.Genre == "Sci-fi").ToList();
                    break;
                case 8:
                    item = item.Where(x => x.Genre == "Cooking").ToList();
                    break;
                case 9:
                    item = item.Where(x => x.Genre == "Educational").ToList();
                    break;
                default:
                    break;
            }
            foreach (Item i in item)
            {
                lvItems.Items.Add(new ListViewItem(new String[] { i.Id.ToString(), i.Title.ToString(), i.Author.ToString(), i.Publisher.ToString(), i.Genre.ToString() }));
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            List<Item> items = Provider.Container.GetInstance<IItemManager>().GetItems();
            lvItems.Items.Clear();
            string title = tbSearchTitle.Text;
            items = items.Where(x => x.Title.ToLower().Contains(title.ToLower())).ToList();
            foreach (Item i in items)
            {
                lvItems.Items.Add(new ListViewItem(new String[] { i.Id.ToString(), i.Title.ToString(), i.Author.ToString(), i.Publisher.ToString(), i.Genre.ToString() }));
            }
        }

     
    }
}
