using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Pages
{
    public class AddItemModel : PageModel
    {
        [BindProperty]
        public Book? Book { get; set; }


        [Display(Name = "File")]
        public IFormFile? FormFile { get; set; }
        public void OnGet()
        {
        }
        public async Task<IActionResult> OnPostExit(int valuecount)
        {
            // remove the cookie
            if (Request.Cookies.ContainsKey("personID"))
            {
                Response.Cookies.Append("personID", "");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("Username");
            return new RedirectToPageResult("Index");
        }
        public void OnPost()
        {
            if (ModelState.IsValid)
            {
                if (Book != null)
                {
                    Provider.Container.GetInstance<IItemManager>().CreateItem(Book);
                    ViewData["Message"] = "Item with title" + Book.Title + " and author " + Book.Author + " has been successfully.";
                }
            }
        }
    }
}
