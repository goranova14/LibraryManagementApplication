using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Pages
{
    [Authorize]

    public class IndividualItemModel : PageModel
    {
        public Item Item { get; set; }
        [BindProperty]
        public Guid ItemId { get; set; }
        [BindProperty]
        public string ItemTitle { get; set; }
        [BindProperty]
        public string ItemDescription { get; set; }
        [BindProperty]
        public string ItemAuthor { get; set; }
        [BindProperty]
        public string ItemPublisher { get; set; }
        [BindProperty]
        public string ItemGenre { get; set; }
        [BindProperty]
        [Required]

        public int Quantity { get; set; }
        [BindProperty]
        public Review Review { get; set; }
        [BindProperty]
        [Required]
        public string ReviewText { get; set; }
        public List<Review> Reviews { get; set; }

        private string message = "";

        public void OnGet()
        {
            Guid id = Guid.Parse(HttpContext.Session.GetString("ItemID"));
            Item = Provider.Container.GetInstance<IItemManager>().GetItemByID(id);
            ItemId = Item.Id;
            ItemTitle = Item.Title;
            ItemDescription = Item.Description;
            ItemAuthor = Item.Author;
            ItemPublisher = Item.Publisher;
            ItemGenre = Item.Genre;
            Guid personID = Guid.Parse(HttpContext.Session.GetString("LoggedInUser"));
            Reviews = Provider.Container.GetInstance<IReviewManager>().GetReviews(ItemId);
        }
        public async Task<IActionResult> OnPostExit(int valuecount)
        {
            // remove the cookie
            if (Request.Cookies.ContainsKey("personID"))
            {
                Response.Cookies.Append("personID", "");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("Username");
            return new RedirectToPageResult("Index");
        }
        public IActionResult OnPostReview(int valuecount, Guid id)
        {
            Review review = new();
            review = Review;
            if (review != null)
            {
                Review.BookID = id;
                Review.PersonID = Guid.Parse(HttpContext.Session.GetString("LoggedInUser"));
                Review.ReviewText = ReviewText;
                Provider.Container.GetInstance<IReviewManager>().AddReview(review);
                message = "Your review has been successfully added.";

            }
            else
            {
                message = "Your review should has some text.";

            }
            return new RedirectToPageResult("/Result");


        }
        public IndividualItemModel()
        {
            Reviews = new List<Review>();
            if (Item is not null)
            {

                Reviews = Provider.Container.GetInstance<IReviewManager>().GetReviews(ItemId);
                Guid id = ItemId;
                Item = Provider.Container.GetInstance<IItemManager>().GetItemByID(id);
                ItemId = Item.Id;
                ItemTitle = Item.Title;
                ItemDescription = Item.Description;
                ItemAuthor = Item.Author;
                ItemPublisher = Item.Publisher;
                ItemGenre = Item.Genre;
                Guid personID = Guid.Parse(HttpContext.Session.GetString("LoggedInUser"));
            }

        }

        public IActionResult OnPostEdit(int valuecount, Guid id, Guid reviewID)
        {
            Reviews = Provider.Container.GetInstance<IReviewManager>().GetReviews(id);
            Review review = Provider.Container.GetInstance<IReviewManager>().GetReview(reviewID);
            if (Review.ReviewText != null)
            {
                review.ReviewText = Review.ReviewText;
                Provider.Container.GetInstance<IReviewManager>().AlterReview(review);
                message = "Successfully updated review";
                HttpContext.Session.SetString("message", message.ToString());
            }
            else
            {
                ViewData["Message"] = "Put your edited review in the text area";


            }
            return new RedirectToPageResult("/Result");


        }
        public IActionResult OnPostDelete(int valuecount, Guid id, Guid reviewID)
        {
            Reviews = Provider.Container.GetInstance<IReviewManager>().GetReviews(id);
            Review review = Provider.Container.GetInstance<IReviewManager>().GetReview(reviewID);
           
                Provider.Container.GetInstance<IReviewManager>().DeleteReview(review);
                message = "Successfully deleted review";
                HttpContext.Session.SetString("message", message.ToString());
            
                        
            return new RedirectToPageResult("/Result");


        }
        public IActionResult OnPostRequest(int valuecount, Guid id)
        {
            Request request = new();
            if (Quantity > 0)
            {
                request.PersonID = Guid.Parse(HttpContext.Session.GetString("LoggedInUser"));
                request.BookID = id;
                request.Quantity = Quantity;
                Provider.Container.GetInstance<IRequestManager>().CreateRequest(request);
                message = "Your request has been successfully sent";
                HttpContext.Session.SetString("message", message.ToString());


                return new RedirectToPageResult("/Result");
            }
            else
            {
                ViewData["Message"] = "Put a quantity bigger than 0";
                return null;

            }
            return null;
        }
    }
}
