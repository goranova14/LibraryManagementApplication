using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Pages
{
    public class AddEBookcshtmlModel : PageModel
    {
        [BindProperty]
        public EBook EBook { get; set; }


        [Display(Name = "File")]
        public IFormFile? FormFile { get; set; }
        public void OnGet()
        {
        }
        public async Task<IActionResult> OnPostExit(int valuecount)
        {
            // remove the cookie
            if (Request.Cookies.ContainsKey("personID"))
            {
                Response.Cookies.Append("personID", "");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("Username");
            return new RedirectToPageResult("Index");
        }
        public void OnPost()
        {
            if (ModelState.IsValid)
            {
                if (EBook != null)
                {
                    if (Provider.Container.GetInstance<IItemManager>().CreateItem(EBook)==true)
                    {
                    ViewData["Message"] = "Item with title" + EBook.Title + " and author " + EBook.Author + " has been successfully.";

                    } 
                }
            }
        }

    }
}
