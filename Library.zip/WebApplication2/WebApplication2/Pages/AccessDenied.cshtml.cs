using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Pages
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
