﻿using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;

namespace WebApplication2.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public Person Person { get; set; }
        [BindProperty]
        public bool KeepMeLoggedIn { get; set; }

        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public IActionResult OnGet()
        {
            if (Request.Cookies.ContainsKey("personID") && Request.Cookies["personID"].ToString() != "")
            {
                Person Person = new();
                Person.ID = Guid.Parse(Request.Cookies["personID"]);
                Person = Provider.Container.GetInstance<IPersonManager>().GetPerson(Person.ID);
                HttpContext.Session.SetString("username", Person.Username);
                HttpContext.Session.SetString("LoggedInUser", Person.ID.ToString());
                HttpContext.Session.SetString("Username", Person.Username.ToString());
                HttpContext.Session.SetString("Name", Person.Name.ToString());
                HttpContext.Session.SetString("Surname", Person.SurName.ToString());
                HttpContext.Session.SetString("Address", Person.Address.ToString());
                HttpContext.Session.SetString("Role", Person.Role.Name.ToString());

                return new RedirectToPageResult("/HomePageA");
            }
            else
            {
                return Page();

            }
        }
        public async Task<IActionResult> OnPostExit(int valuecount)
        {
            // remove the cookie
            if (Request.Cookies.ContainsKey("personID"))
            {
                Response.Cookies.Append("personID", "");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("username");
            return new RedirectToPageResult("Index");
        }
        public IActionResult OnPost()
        {
            if (Provider.Container.GetInstance<IPersonManager>().Login(Person.Username, Person.Password) is Person p)
            {
                // set a cookie to keep me logged in (if checked)
                if (KeepMeLoggedIn)
                {
                    // set a cookie with the user name
                    CookieOptions cOptions = new();
                    cOptions.Expires = DateTime.Now.AddDays(2000);
                    Response.Cookies.Append("personID", p.ID.ToString(), cOptions);
                }
                List<Claim> claims = new();
                claims.Add(new Claim(ClaimTypes.Name, Person.Username));
                claims.Add(new Claim("id", "1"));

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                HttpContext.SignInAsync(new ClaimsPrincipal(claimsIdentity));
                HttpContext.Session.SetString("username", p.Username.ToString());
                HttpContext.Session.SetString("LoggedInUser", p.ID.ToString());
                HttpContext.Session.SetString("Username", p.Username.ToString());
                HttpContext.Session.SetString("Name", p.Name.ToString());
                HttpContext.Session.SetString("Surname", p.SurName.ToString());
                HttpContext.Session.SetString("Address", p.Address.ToString());

                if (p.Role.AccessLevel == 100 || p.Role.AccessLevel==50)
                {
                    claims.Add(new Claim(ClaimTypes.AuthorizationDecision, "admin"));
                    HttpContext.Session.SetString("Role", p.Role.Name.ToString());


                    return Redirect("/HomepageA");

                }
                else
                {
                    HttpContext.Session.SetString("Role", p.Role.Name.ToString());

                    return Redirect("/HomePageA");

                }
            }
            else
            {
                ViewData["MessageAlert"] = "Wrong password or username";
            }

            return Page();
        }
    }
}