using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Pages
{
    [Authorize]

    public class ChangePasswordModel : PageModel
    {
        [BindProperty]
        public Person Person { get; set; }
        public ChangePasswordModel()
        {

        }

        public void OnGet()
        {
        }
        public async Task<IActionResult> OnPostExit(int valuecount)
        {
            // remove the cookie
            if (Request.Cookies.ContainsKey("personID"))
            {
                Response.Cookies.Append("personID", "");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("Username");
            return new RedirectToPageResult("Index");
        }
        public void OnPost()
        {
            Person.ID = Guid.Parse(HttpContext.Session.GetString("LoggedInUser"));
            Person.Password = BCrypt.Net.BCrypt.HashPassword(Person.Password);

            if (Provider.Container.GetInstance<IPersonManager>().EditUserPassword(Person))
            {
                ViewData["Message"] = "Your information has been updated successfully.";
            }

        }
    }
}
