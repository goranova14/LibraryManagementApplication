using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Pages
{
    public class SignUpModel : PageModel
    {
        [BindProperty]
        public Person Person { get; set; }
        public void OnGet()
        {
        }
        public void OnPost()
        {
            if (ModelState.IsValid)
            {
                if (Person != null)
                {

                    Person.Password = BCrypt.Net.BCrypt.HashPassword(Person.Password);
                    Person.Role = new Role() { ID = new Guid("6FD29C8F-0532-469C-99BB-9EEE6EA9737C") };
                    List<Person> people = Provider.Container.GetInstance<IPersonManager>().GetAll();
                    int matches = people.Where(p => Person.Username == p.Username).Count();

                    if (matches == 0)
                    {
                        Person.Role = new Role()
                        {
                            ID = new Guid("6FD29C8F-0532-469C-99BB-9EEE6EA9737C")//regular user ID

                        };
                        Provider.Container.GetInstance<IPersonManager>().AddUser(Person);

                        ViewData["Message"] = "User with username " + Person.Username + " has been successfully.";
                    }
                    else
                    {
                        ViewData["Message"] = "User with username already exists.";

                    }
                }
                else
                {
                    ViewData["Message"] = "User was not created, try again.";
                }
            }
        }
    }
}
