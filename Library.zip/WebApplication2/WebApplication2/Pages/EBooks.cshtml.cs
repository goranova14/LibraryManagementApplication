using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static System.Reflection.Metadata.BlobBuilder;

namespace WebApplication2.Pages
{
    [Authorize]

    public class EBooksModel : PageModel
    {
        public ItemManager ItemManager { get; set; }
        public List<EBook> EBooks { get; set; }
        public int CurrentPage { get; set; } = 1;

        public int Count { get; set; }

        public int PageSize { get; set; } = 10;

        public int TotalPages => (int)Math.Ceiling(decimal.Divide(Count, PageSize));

        public bool EnablePrevious => CurrentPage > 1;

        public bool EnableNext => CurrentPage < TotalPages;

        public void OnGet(int currentPage)
        {
            CurrentPage = currentPage == 0 ? 1 : currentPage;


            if (CurrentPage > TotalPages)
                CurrentPage = TotalPages;

            EBooks = new List<EBook>();
            foreach (Item item in Provider.Container.GetInstance<IItemManager>().GetItems())
            {
                if (item.GetType() == typeof(EBook))
                {
                    EBooks.Add((EBook)item);
                }
            }
            Count = EBooks.Count();

            EBooks = EBooks.Skip((CurrentPage - 1) * PageSize)
                .Take(PageSize)
                .ToList();
        }
        public async Task<IActionResult> OnPostExit(int valuecount)
        {
            // remove the cookie
            if (Request.Cookies.ContainsKey("personID"))
            {
                Response.Cookies.Append("personID", "");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("Username");
            return new RedirectToPageResult("Index");
        }
        public void OnPost()
        {
            EBooks = new List<EBook>();
            foreach (Item item in Provider.Container.GetInstance<IItemManager>().GetItems())
            {
                if (item.GetType() == typeof(EBook))
                {
                    EBooks.Add((EBook)item);
                }
            }
            var num = Request.Form["number"];
            var title = Request.Form["CurrentFilter"];
            EBooks.Where(s => s.Title.ToUpper().Contains(title.ToString().ToUpper()));
            switch (num)
            {
                case "1":
                    EBooks.Sort((a, b) => a.Title.CompareTo(b.Title));
                    break;
                case "2":
                    EBooks.Sort((a, b) => b.Title.CompareTo(a.Title));
                    break;
                case "3":
                    EBooks = EBooks.Where(x => x.Genre == "Horror").ToList();
                    break;
                case "4":
                    EBooks = EBooks.Where(x => x.Genre == "Comedy").ToList();
                    break;
                case "5":
                    EBooks = EBooks.Where(x => x.Genre == "Romance").ToList();
                    break;
                case "6":
                    EBooks = EBooks.Where(x => x.Genre == "Fiction").ToList();
                    break;
                case "7":
                    EBooks = EBooks.Where(x => x.Genre == "Triller").ToList();
                    break;
                case "8":
                    EBooks = EBooks.Where(x => x.Genre == "Sci-fi").ToList();
                    break;
                case "9":
                    EBooks = EBooks.Where(x => x.Genre == "Cooking").ToList();
                    break;
                case "10":
                    EBooks = EBooks.Where(x => x.Genre == "Educational").ToList();
                    break;

                default:
                    EBooks.ToList();
                    break;
            }

        }



        public IActionResult OnPostMore(int valuecount, Guid id)
        {
            HttpContext.Session.SetString("ItemID", id.ToString());

            return new RedirectToPageResult("/IndividualItem");
        }
        public void OnPostSearch(int valuecount)
        {

            EBooks = new List<EBook>();
            foreach (Item item in Provider.Container.GetInstance<IItemManager>().GetItems())
            {
                if (item.GetType() == typeof(EBook))
                {
                    EBooks.Add((EBook)item);
                }
            }
            string title = Request.Form["CurrentFilter"];
            EBooks = EBooks.Where(s => s.Title.ToUpper().Contains(title.ToUpper())).ToList();

        }
    }
}
