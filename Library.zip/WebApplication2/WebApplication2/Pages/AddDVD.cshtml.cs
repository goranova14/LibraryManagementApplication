using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Pages
{
    public class Index1Model : PageModel
    {
        [BindProperty]
        public DVD? DVD { get; set; }


        [Display(Name = "File")]
        public IFormFile? FormFile { get; set; }
        public void OnGet()
        {
        }
        public async Task<IActionResult> OnPostExit(int valuecount)
        {
            // remove the cookie
            if (Request.Cookies.ContainsKey("personID"))
            {
                Response.Cookies.Append("personID", "");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("Username");
            return new RedirectToPageResult("Index");
        }
        public void OnPost()
        {
            if (ModelState.IsValid)
            {
                if (DVD != null)
                {

                    Provider.Container.GetInstance<IItemManager>().CreateItem(DVD);
                    //library.AddItem(DVD);
                    ViewData["Message"] = "Item with title" + DVD.Title + " and author " + DVD.Author + " has been successfully.";
                }
            }
        }
    }
}
