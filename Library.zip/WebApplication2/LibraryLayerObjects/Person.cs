﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Xml.Linq;

namespace LibraryLayerObjects
{
    public class Person
    {
        public Person()
        {
            /// <summary>
            /// empty constructor and public set beacuse of model binding
            /// </summary>
        }

        public Person(DataRow dataRow)
        {
            ID = (Guid)dataRow[nameof(ID)];
            Name = (String)dataRow[nameof(Name)];
            Username = (String)dataRow[nameof(Username)];
            SurName = (String)dataRow[nameof(SurName)];
            Address = (String)dataRow[nameof(Address)];

            //Role = (Guid)dataRow[nameof(ID)];
            // maybe make this an enum value?


        }
        public Person(DataRow personRow, Role? role)
        {
            ID = (Guid)personRow[nameof(ID)];
            Name = (String)personRow[nameof(Name)];
            Username = (String)personRow[nameof(Username)];
            SurName = (String)personRow[nameof(SurName)];
            Address = (String)personRow[nameof(Address)];
            //Role = (Guid)dataRow[nameof(ID)];
            // maybe make this an enum value?
            Role = role ?? new Role();
        }

        public Guid ID { get; set; }
        [ValidateNever]
        public Role Role { get; set; }
        [Required(ErrorMessage = "Please enter Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please enter Username")]
        public string Username { get; set; }
        [Required(ErrorMessage = "Please enter Last name")]

        public string SurName { get; set; }
        [Required(ErrorMessage = "Please enter Address")]

        public string Address { get; set; }
        [Required(ErrorMessage = "Please enter Password")]
        public string Password { get; set; }

        public override bool Equals(object? obj)
        {
            if (obj == null)
                return false;
            if(obj is Person p)
            return
                this.ID == p.ID
                && this.Name == p.Name
                && this.Username == p.Username
                && this.SurName == p.SurName
                && this.Address == p.Address
                && this.Role?.ID == p.Role?.ID;
            return false;
        }

    }
}
