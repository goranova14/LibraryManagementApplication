﻿namespace LibraryLayerObjects
{
    public class Book : Item
    {
        public int Pages { get; set; }
        public Book()
        {
            /// <summary>
            /// empty constructor and public set beacuse of model binding
            /// </summary>
        }
        public override string ToString()
        {
            return base.ToString() + Pages.ToString();
        }
        public override bool Equals(object? obj)
        {
            if (obj == null)
                return false;
            if (obj is Item p)
                return
                    this.Id == p.Id
                    && this.Title == p.Title
                    && this.Author == p.Author
                    && this.Publisher == p.Publisher
                    && this.Genre == p.Genre;
            return false;
        }
    }
}
