﻿using LibraryBusiness;
using LibraryLayer;

namespace WebApplication2
{
    public static class Provider
    {
        public static LibraryContainer Container { get; }
        static Provider()
        {
            Container = new LibraryContainer(new DatabaseInstance());
            Container.Register<IPersonManager, PersonManager>();
            Container.Register<IReviewManager, ReviewManager>();
            Container.Register<IRequestManager, RequestManager>();
            Container.Register<IItemManager, ItemManager>();
        }
    }
}
