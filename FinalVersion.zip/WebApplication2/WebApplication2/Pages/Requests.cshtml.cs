using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Pages
{
    [Authorize]

    public class RequestsModel : PageModel
    {

        [BindProperty]
        public List<Request> requests { get; set; }
        public string title { get; set; }

        public async Task<IActionResult> OnPostExit(int valuecount)
        {
            // remove the cookie
            if (Request.Cookies.ContainsKey("personID"))
            {
                Response.Cookies.Append("personID", "");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("Username");
            return new RedirectToPageResult("Index");
        }
        public void OnGet(Guid id)
        {
            Guid PersonID = Guid.Parse(HttpContext.Session.GetString("LoggedInUser"));
            requests = Provider.Container.GetInstance<IRequestManager>().GetRequests(PersonID);
            foreach (Request item in requests)
            {
                Item newItem = Provider.Container.GetInstance<IItemManager>().GetItemByID(item.BookID);
                title = newItem.Title;
            }
            if (requests.Count() == 0)
            {
                ViewData["Message"] = "Your requests are being checked. For now there are not accepted or declined requests.";

            }
        }
        public RequestsModel()
        {


        }
        public void OnPost()
        {

        }
    }
}
