using LibraryLayer;
using LibraryLayerObjects;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Pages
{
    [Authorize]

    public class SettingsModel : PageModel
    {
        [BindProperty]
        public Person Person { get; set; }
        public SettingsModel()
        {

            Person = new Person();

        }
        public void OnGet()
        {
            Person = Provider.Container.GetInstance<IPersonManager>().GetPerson(Guid.Parse(HttpContext.Session.GetString("LoggedInUser")));
        }
        public async Task<IActionResult> OnPostExit(int valuecount)
        {
            // remove the cookie
            if (Request.Cookies.ContainsKey("personID"))
            {
                Response.Cookies.Append("personID", "");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("Username");
            return new RedirectToPageResult("Index");
        }
        public IActionResult OnPostChangePassword(int valuecount)
        {
            return Redirect("/ChangePassword");
        }
        public void OnPostChangeInfo(int valuecount)
        {
            Person.ID = Guid.Parse(HttpContext.Session.GetString("LoggedInUser"));
            Person person = Provider.Container.GetInstance<IPersonManager>().GetPerson(Person.ID);
            Person.Role = person.Role;


            if (Provider.Container.GetInstance<IPersonManager>().EditUser(Person))
            {
                ViewData["Message"] = "Your information has been updated successfully.";

            }

        }
    }
}
