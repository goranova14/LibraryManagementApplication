﻿using LibraryLayer;
using LibraryLayerObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DenisBetterTestingProject
{
    public class ItemManagerTests
    {
        private LibraryContainer Container { get; set; }

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            Container = new LibraryContainer(new DatabaseMock());
            Container.Register<IItemManager, ItemManager>();
        }
        [Test]
        public void AlterItem()
        {
            Item i = new Book()
            {
                Title = "Bla",
                Author = "Deni",
                Publisher = "Goranova",
                Genre = "Horror",
                Id = Guid.NewGuid(),
                
            };
            IItemManager itemManager = Container.GetInstance<IItemManager>();
           itemManager.CreateItem(i);
            i.Title = "JustBla";
            Assert.IsTrue(itemManager.AlterItem(i));
            Assert.That(itemManager.GetItemByID(i.Id), Is.EqualTo(i));
        }

        [Test]
        public void GetItems()
        {
            IItemManager itemManager = Container.GetInstance<IItemManager>();
            Assert.That(itemManager.GetItems(), Is.EqualTo(new List<Item>()

            {
                new Book()
                {
                    Title = "Biggg",
                    Author = "Deni",
                    Pages=212,
                    Description="Pipi",
                    Genre="Horror",
                    Publisher="Peter"
                },
                new Book()
                {
                    Title = "Small",
                    Author = "Item"
                }
            }));
        }
        [Test]
        public void CreateItem()
        {
            Item item = new Book()
            {
                Title = "My book",
                Author = "Deni",
                Publisher = "Goranova",
                Genre = "Comdey",
                Pages = 222,
                Id = Guid.NewGuid(),
            };
            IItemManager itemManager = Container.GetInstance<IItemManager>();
            Assert.IsTrue(itemManager.CreateItem(item));
            Assert.IsFalse(itemManager.CreateItem(null));
        }

    }
}
