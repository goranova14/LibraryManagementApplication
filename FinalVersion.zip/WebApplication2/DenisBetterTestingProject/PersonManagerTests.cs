using LibraryLayer;
using LibraryLayerObjects;

namespace DenisBetterTestingProject
{
    public class PersonManagerTests
    {
        private LibraryContainer Container { get; set; }

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            Container = new LibraryContainer(new DatabaseMock());
            Container.Register<IPersonManager, PersonManager>();
        }

        [Test]
        public void GetID()
        {
            IPersonManager personManager = Container.GetInstance<IPersonManager>();
            Guid id = Guid.NewGuid();
            Person a = new Person()
            {
                ID = id,
                Address = "Straat",
                Name = "Miribiri",
                SurName = "Piribiri",
                Role = null,
                Username = "MiriMeister",
                Password = "Sekrit"
            };
            Assert.IsTrue(personManager.AddUser(a));
            Person p = personManager.GetPerson(id);

            Assert.That(p, Is.EqualTo(a));
        }

        [Test]
        public void Login()
        {
            string username = "BasTheAmazing";
            string password = "BooksNStuff";
            Person person = new Person()
            {
                Role = new Role() { ID  = Guid.NewGuid()},
                Name = "Bas",
                SurName = "M",
                Username = username,
                Address = "V city",
                ID = Guid.NewGuid(),
                Password = password
            };
            IPersonManager personManager = Container.GetInstance<IPersonManager>();
            Assert.IsTrue(personManager.AddUser(person));
            Assert.That(personManager.Login(username, password), Is.EqualTo(person));
            Assert.That(personManager.Login("BigDeni", "NotMyPassword"), Is.Null);
        }

        [Test]
        public void CreatePerson()
        {
            Person person = new Person()
            {
                Role = null,
                Name = "Deni",
                SurName = "Goranova",
                Username = "coolDeni",
                Address = "Cloudy Eindhoven",
                ID = Guid.NewGuid(),
                Password = "Sekrit"
            };
            IPersonManager personManager = Container.GetInstance<IPersonManager>();
            Assert.IsTrue(personManager.AddUser(person));
            Assert.IsFalse(personManager.AddUser(null));
        }

        [Test]
        public void GetAll()
        {
            IPersonManager personManager = Container.GetInstance<IPersonManager>();
            Assert.That(personManager.GetAll(), Is.EqualTo(new List<Person>()
            {
                new Person()
                {
                    Name = "Big Deni",
                    Username = "TheDeniMaister",
                    Address="Kozloduy",
                    SurName="Pipi"
                },
                new Person()
                {
                    Name = "Ivan",
                    Username = "Ivan"
                }
            }));
        }

        [Test]
        public void DeletePerson()
        {
            IPersonManager personManager = Container.GetInstance<IPersonManager>();
            Assert.IsTrue(personManager.DeleteUser(new Person()));
        }
        [Test]
        public void UpdatePassword()
        {
            Person person = new Person()
            {
                Role = null,
                Name = "Deni",
                SurName = "Goranova",
                Username = "coolDeni",
                Address = "Cloudy Eindhoven",
                ID = Guid.NewGuid(),
                Password = "Sekrit"
            };
            IPersonManager personManager = Container.GetInstance<IPersonManager>();
            Assert.IsTrue(personManager.AddUser(person));
            person.Password = BCrypt.Net.BCrypt.HashPassword("NotSoSekrit");
            Assert.IsTrue(personManager.EditUserPassword(person));
            Assert.That(personManager.GetPerson(person.ID), Is.EqualTo(person));
        }

        [Test]
        public void EditUser()
        {
            Person person = new Person()
            {
                Role = null,
                Name = "Deni",
                SurName = "Goranova",
                Username = "coolDeni",
                Address = "Cloudy Eindhoven",
                ID = Guid.NewGuid(),
                Password = "Sekrit"
            };
            IPersonManager personManager = Container.GetInstance<IPersonManager>();
            Assert.IsTrue(personManager.AddUser(person));
            person.Username = "JustDeni";
            Assert.IsTrue(personManager.EditUser(person));
            Assert.That(personManager.GetPerson(person.ID), Is.EqualTo(person));
        }
    }
}