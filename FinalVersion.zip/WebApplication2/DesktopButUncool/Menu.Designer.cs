﻿namespace DesktopButUncool
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.tcAdmin = new System.Windows.Forms.TabControl();
            this.tpHome = new System.Windows.Forms.TabPage();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.tpPeople = new System.Windows.Forms.TabPage();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.tbSearchU = new System.Windows.Forms.TextBox();
            this.lblOrder = new System.Windows.Forms.Label();
            this.gbEditInfo = new System.Windows.Forms.GroupBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.cbRole = new System.Windows.Forms.ComboBox();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.btnEdit = new System.Windows.Forms.Button();
            this.tbAddress = new System.Windows.Forms.TextBox();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbSortBy = new System.Windows.Forms.ComboBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.lvPeople = new System.Windows.Forms.ListView();
            this.tpRequests = new System.Windows.Forms.TabPage();
            this.gbStatus = new System.Windows.Forms.GroupBox();
            this.btnSubmitStatus = new System.Windows.Forms.Button();
            this.cbStatus = new System.Windows.Forms.ComboBox();
            this.lvRequests = new System.Windows.Forms.ListView();
            this.tpItems = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.lblSearchItem = new System.Windows.Forms.Label();
            this.tbSearchTitle = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbSort = new System.Windows.Forms.ComboBox();
            this.lvItems = new System.Windows.Forms.ListView();
            this.gbEdit = new System.Windows.Forms.GroupBox();
            this.rtbDescription = new System.Windows.Forms.RichTextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbGenre = new System.Windows.Forms.ComboBox();
            this.tbAuthor = new System.Windows.Forms.TextBox();
            this.tbTitle = new System.Windows.Forms.TextBox();
            this.btnEditInfo = new System.Windows.Forms.Button();
            this.tbPublisher = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tcAdmin.SuspendLayout();
            this.tpHome.SuspendLayout();
            this.tpPeople.SuspendLayout();
            this.gbEditInfo.SuspendLayout();
            this.tpRequests.SuspendLayout();
            this.gbStatus.SuspendLayout();
            this.tpItems.SuspendLayout();
            this.gbEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcAdmin
            // 
            this.tcAdmin.Controls.Add(this.tpHome);
            this.tcAdmin.Controls.Add(this.tpPeople);
            this.tcAdmin.Controls.Add(this.tpRequests);
            this.tcAdmin.Controls.Add(this.tpItems);
            this.tcAdmin.Location = new System.Drawing.Point(12, 12);
            this.tcAdmin.Name = "tcAdmin";
            this.tcAdmin.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tcAdmin.SelectedIndex = 0;
            this.tcAdmin.Size = new System.Drawing.Size(1408, 734);
            this.tcAdmin.TabIndex = 0;
            // 
            // tpHome
            // 
            this.tpHome.BackColor = System.Drawing.Color.Silver;
            this.tpHome.Controls.Add(this.label11);
            this.tpHome.Controls.Add(this.btnLogout);
            this.tpHome.Controls.Add(this.lblWelcome);
            this.tpHome.Location = new System.Drawing.Point(4, 29);
            this.tpHome.Name = "tpHome";
            this.tpHome.Padding = new System.Windows.Forms.Padding(3);
            this.tpHome.Size = new System.Drawing.Size(1400, 701);
            this.tpHome.TabIndex = 0;
            this.tpHome.Text = "Home";
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Snow;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLogout.Location = new System.Drawing.Point(1261, 617);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(94, 41);
            this.btnLogout.TabIndex = 2;
            this.btnLogout.Text = "Log out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Vladimir Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblWelcome.Location = new System.Drawing.Point(140, 29);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(1001, 73);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome to Student Library management system";
            // 
            // tpPeople
            // 
            this.tpPeople.BackColor = System.Drawing.Color.Silver;
            this.tpPeople.Controls.Add(this.btnSearch);
            this.tpPeople.Controls.Add(this.lblSearch);
            this.tpPeople.Controls.Add(this.tbSearchU);
            this.tpPeople.Controls.Add(this.lblOrder);
            this.tpPeople.Controls.Add(this.gbEditInfo);
            this.tpPeople.Controls.Add(this.cbSortBy);
            this.tpPeople.Controls.Add(this.btnDelete);
            this.tpPeople.Controls.Add(this.btnRegister);
            this.tpPeople.Controls.Add(this.lvPeople);
            this.tpPeople.Location = new System.Drawing.Point(4, 29);
            this.tpPeople.Name = "tpPeople";
            this.tpPeople.Padding = new System.Windows.Forms.Padding(3);
            this.tpPeople.Size = new System.Drawing.Size(1400, 701);
            this.tpPeople.TabIndex = 1;
            this.tpPeople.Text = "People";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSearch.Location = new System.Drawing.Point(1283, 267);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(105, 37);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSearch.Location = new System.Drawing.Point(1216, 181);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(148, 50);
            this.lblSearch.TabIndex = 19;
            this.lblSearch.Text = "Search user\r\n(Insert username)";
            // 
            // tbSearchU
            // 
            this.tbSearchU.Location = new System.Drawing.Point(1216, 234);
            this.tbSearchU.Name = "tbSearchU";
            this.tbSearchU.Size = new System.Drawing.Size(163, 27);
            this.tbSearchU.TabIndex = 18;
            // 
            // lblOrder
            // 
            this.lblOrder.AutoSize = true;
            this.lblOrder.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblOrder.Location = new System.Drawing.Point(1216, 22);
            this.lblOrder.Name = "lblOrder";
            this.lblOrder.Size = new System.Drawing.Size(74, 25);
            this.lblOrder.TabIndex = 17;
            this.lblOrder.Text = "Sort by:";
            // 
            // gbEditInfo
            // 
            this.gbEditInfo.Controls.Add(this.lblRole);
            this.gbEditInfo.Controls.Add(this.cbRole);
            this.gbEditInfo.Controls.Add(this.tbLastName);
            this.gbEditInfo.Controls.Add(this.tbFirstName);
            this.gbEditInfo.Controls.Add(this.btnEdit);
            this.gbEditInfo.Controls.Add(this.tbAddress);
            this.gbEditInfo.Controls.Add(this.tbUsername);
            this.gbEditInfo.Controls.Add(this.label5);
            this.gbEditInfo.Controls.Add(this.label2);
            this.gbEditInfo.Controls.Add(this.label4);
            this.gbEditInfo.Controls.Add(this.label3);
            this.gbEditInfo.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.gbEditInfo.Location = new System.Drawing.Point(18, 267);
            this.gbEditInfo.Name = "gbEditInfo";
            this.gbEditInfo.Size = new System.Drawing.Size(406, 428);
            this.gbEditInfo.TabIndex = 14;
            this.gbEditInfo.TabStop = false;
            this.gbEditInfo.Text = "Edit information";
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(12, 280);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(50, 25);
            this.lblRole.TabIndex = 16;
            this.lblRole.Text = "Role:";
            // 
            // cbRole
            // 
            this.cbRole.FormattingEnabled = true;
            this.cbRole.Items.AddRange(new object[] {
            "Admin ",
            "Client"});
            this.cbRole.Location = new System.Drawing.Point(94, 306);
            this.cbRole.Name = "cbRole";
            this.cbRole.Size = new System.Drawing.Size(159, 33);
            this.cbRole.TabIndex = 15;
            // 
            // tbLastName
            // 
            this.tbLastName.Location = new System.Drawing.Point(94, 112);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(159, 31);
            this.tbLastName.TabIndex = 6;
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(94, 47);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(159, 31);
            this.tbFirstName.TabIndex = 2;
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(157, 356);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(142, 56);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "Edit information";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // tbAddress
            // 
            this.tbAddress.Location = new System.Drawing.Point(95, 239);
            this.tbAddress.Name = "tbAddress";
            this.tbAddress.Size = new System.Drawing.Size(158, 31);
            this.tbAddress.TabIndex = 3;
            // 
            // tbUsername
            // 
            this.tbUsername.Location = new System.Drawing.Point(95, 179);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(158, 31);
            this.tbUsername.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "City:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "First name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 25);
            this.label4.TabIndex = 9;
            this.label4.Text = "Username:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Last name:";
            // 
            // cbSortBy
            // 
            this.cbSortBy.FormattingEnabled = true;
            this.cbSortBy.Items.AddRange(new object[] {
            "Alphabetically(A-Z)",
            "Alphabetically(Z-A)",
            "Admins",
            "Clients"});
            this.cbSortBy.Location = new System.Drawing.Point(1216, 57);
            this.cbSortBy.Name = "cbSortBy";
            this.cbSortBy.Size = new System.Drawing.Size(151, 28);
            this.cbSortBy.TabIndex = 13;
            this.cbSortBy.SelectedIndexChanged += new System.EventHandler(this.cbSortBy_SelectedIndexChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDelete.Location = new System.Drawing.Point(1115, 547);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(206, 72);
            this.btnDelete.TabIndex = 12;
            this.btnDelete.Text = "Delete user";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRegister.Location = new System.Drawing.Point(1115, 436);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(206, 83);
            this.btnRegister.TabIndex = 11;
            this.btnRegister.Text = "Register new user";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // lvPeople
            // 
            this.lvPeople.Location = new System.Drawing.Point(6, 22);
            this.lvPeople.Name = "lvPeople";
            this.lvPeople.Size = new System.Drawing.Size(1204, 229);
            this.lvPeople.TabIndex = 0;
            this.lvPeople.UseCompatibleStateImageBehavior = false;
            this.lvPeople.View = System.Windows.Forms.View.Details;
            this.lvPeople.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // tpRequests
            // 
            this.tpRequests.BackColor = System.Drawing.Color.LightGray;
            this.tpRequests.Controls.Add(this.gbStatus);
            this.tpRequests.Controls.Add(this.lvRequests);
            this.tpRequests.Location = new System.Drawing.Point(4, 29);
            this.tpRequests.Name = "tpRequests";
            this.tpRequests.Size = new System.Drawing.Size(1400, 701);
            this.tpRequests.TabIndex = 2;
            this.tpRequests.Text = "Requests";
            // 
            // gbStatus
            // 
            this.gbStatus.BackColor = System.Drawing.Color.DarkGray;
            this.gbStatus.Controls.Add(this.btnSubmitStatus);
            this.gbStatus.Controls.Add(this.cbStatus);
            this.gbStatus.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.gbStatus.Location = new System.Drawing.Point(387, 283);
            this.gbStatus.Name = "gbStatus";
            this.gbStatus.Size = new System.Drawing.Size(403, 138);
            this.gbStatus.TabIndex = 16;
            this.gbStatus.TabStop = false;
            this.gbStatus.Text = "Accept or decline request";
            // 
            // btnSubmitStatus
            // 
            this.btnSubmitStatus.Location = new System.Drawing.Point(265, 97);
            this.btnSubmitStatus.Name = "btnSubmitStatus";
            this.btnSubmitStatus.Size = new System.Drawing.Size(94, 29);
            this.btnSubmitStatus.TabIndex = 3;
            this.btnSubmitStatus.Text = "Submit";
            this.btnSubmitStatus.UseVisualStyleBackColor = true;
            this.btnSubmitStatus.Click += new System.EventHandler(this.btnSubmitStatus_Click);
            // 
            // cbStatus
            // 
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Items.AddRange(new object[] {
            "Accept",
            "Decline"});
            this.cbStatus.Location = new System.Drawing.Point(70, 59);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(151, 33);
            this.cbStatus.TabIndex = 2;
            // 
            // lvRequests
            // 
            this.lvRequests.Location = new System.Drawing.Point(3, 21);
            this.lvRequests.Name = "lvRequests";
            this.lvRequests.Size = new System.Drawing.Size(1388, 229);
            this.lvRequests.TabIndex = 1;
            this.lvRequests.UseCompatibleStateImageBehavior = false;
            this.lvRequests.View = System.Windows.Forms.View.Details;
            this.lvRequests.SelectedIndexChanged += new System.EventHandler(this.lvRequests_SelectedIndexChanged);
            // 
            // tpItems
            // 
            this.tpItems.BackColor = System.Drawing.Color.Silver;
            this.tpItems.Controls.Add(this.button1);
            this.tpItems.Controls.Add(this.lblSearchItem);
            this.tpItems.Controls.Add(this.tbSearchTitle);
            this.tpItems.Controls.Add(this.label8);
            this.tpItems.Controls.Add(this.cbSort);
            this.tpItems.Controls.Add(this.lvItems);
            this.tpItems.Controls.Add(this.gbEdit);
            this.tpItems.Location = new System.Drawing.Point(4, 29);
            this.tpItems.Name = "tpItems";
            this.tpItems.Padding = new System.Windows.Forms.Padding(3);
            this.tpItems.Size = new System.Drawing.Size(1400, 701);
            this.tpItems.TabIndex = 3;
            this.tpItems.Text = "Items";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(1255, 218);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 37);
            this.button1.TabIndex = 25;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // lblSearchItem
            // 
            this.lblSearchItem.AutoSize = true;
            this.lblSearchItem.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSearchItem.Location = new System.Drawing.Point(1143, 132);
            this.lblSearchItem.Name = "lblSearchItem";
            this.lblSearchItem.Size = new System.Drawing.Size(192, 25);
            this.lblSearchItem.TabIndex = 24;
            this.lblSearchItem.Text = "Search item(Insert title)";
            // 
            // tbSearchTitle
            // 
            this.tbSearchTitle.Location = new System.Drawing.Point(1188, 175);
            this.tbSearchTitle.Name = "tbSearchTitle";
            this.tbSearchTitle.Size = new System.Drawing.Size(163, 27);
            this.tbSearchTitle.TabIndex = 23;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(1143, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 25);
            this.label8.TabIndex = 22;
            this.label8.Text = "Sort by:";
            // 
            // cbSort
            // 
            this.cbSort.FormattingEnabled = true;
            this.cbSort.Items.AddRange(new object[] {
            "Alphabetically(A-Z)",
            "Alphabetically(Z-A)",
            "Horror",
            "Comedy",
            "Romance",
            "Fiction",
            "Triller",
            "Sci-fi",
            "Cooking",
            "Educational"});
            this.cbSort.Location = new System.Drawing.Point(1160, 54);
            this.cbSort.Name = "cbSort";
            this.cbSort.Size = new System.Drawing.Size(151, 28);
            this.cbSort.TabIndex = 21;
            this.cbSort.SelectedIndexChanged += new System.EventHandler(this.cbSort_SelectedIndexChanged);
            // 
            // lvItems
            // 
            this.lvItems.Location = new System.Drawing.Point(0, 3);
            this.lvItems.Name = "lvItems";
            this.lvItems.Size = new System.Drawing.Size(1127, 229);
            this.lvItems.TabIndex = 17;
            this.lvItems.UseCompatibleStateImageBehavior = false;
            this.lvItems.View = System.Windows.Forms.View.Details;
            this.lvItems.SelectedIndexChanged += new System.EventHandler(this.lvItems_SelectedIndexChanged);
            // 
            // gbEdit
            // 
            this.gbEdit.BackColor = System.Drawing.Color.LightGray;
            this.gbEdit.Controls.Add(this.rtbDescription);
            this.gbEdit.Controls.Add(this.lblDescription);
            this.gbEdit.Controls.Add(this.label6);
            this.gbEdit.Controls.Add(this.cbGenre);
            this.gbEdit.Controls.Add(this.tbAuthor);
            this.gbEdit.Controls.Add(this.tbTitle);
            this.gbEdit.Controls.Add(this.btnEditInfo);
            this.gbEdit.Controls.Add(this.tbPublisher);
            this.gbEdit.Controls.Add(this.lblTitle);
            this.gbEdit.Controls.Add(this.label9);
            this.gbEdit.Controls.Add(this.lblAuthor);
            this.gbEdit.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.gbEdit.Location = new System.Drawing.Point(27, 256);
            this.gbEdit.Name = "gbEdit";
            this.gbEdit.Size = new System.Drawing.Size(822, 428);
            this.gbEdit.TabIndex = 16;
            this.gbEdit.TabStop = false;
            this.gbEdit.Text = "Edit information";
            // 
            // rtbDescription
            // 
            this.rtbDescription.Location = new System.Drawing.Point(385, 50);
            this.rtbDescription.Name = "rtbDescription";
            this.rtbDescription.Size = new System.Drawing.Size(314, 120);
            this.rtbDescription.TabIndex = 20;
            this.rtbDescription.Text = "";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(342, 23);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(106, 25);
            this.lblDescription.TabIndex = 19;
            this.lblDescription.Text = "Description:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 25);
            this.label6.TabIndex = 16;
            this.label6.Text = "Genre:";
            // 
            // cbGenre
            // 
            this.cbGenre.FormattingEnabled = true;
            this.cbGenre.Items.AddRange(new object[] {
            "Horror",
            "Comedy",
            "Romance",
            "Fiction",
            "Triller",
            "Sci-fi",
            "Cooking",
            "Educational"});
            this.cbGenre.Location = new System.Drawing.Point(94, 281);
            this.cbGenre.Name = "cbGenre";
            this.cbGenre.Size = new System.Drawing.Size(159, 33);
            this.cbGenre.TabIndex = 15;
            // 
            // tbAuthor
            // 
            this.tbAuthor.Location = new System.Drawing.Point(94, 112);
            this.tbAuthor.Name = "tbAuthor";
            this.tbAuthor.Size = new System.Drawing.Size(159, 31);
            this.tbAuthor.TabIndex = 6;
            // 
            // tbTitle
            // 
            this.tbTitle.Location = new System.Drawing.Point(94, 47);
            this.tbTitle.Name = "tbTitle";
            this.tbTitle.Size = new System.Drawing.Size(159, 31);
            this.tbTitle.TabIndex = 2;
            // 
            // btnEditInfo
            // 
            this.btnEditInfo.Location = new System.Drawing.Point(157, 356);
            this.btnEditInfo.Name = "btnEditInfo";
            this.btnEditInfo.Size = new System.Drawing.Size(142, 56);
            this.btnEditInfo.TabIndex = 1;
            this.btnEditInfo.Text = "Edit information";
            this.btnEditInfo.UseVisualStyleBackColor = true;
            this.btnEditInfo.Click += new System.EventHandler(this.btnEditInfo_Click);
            // 
            // tbPublisher
            // 
            this.tbPublisher.Location = new System.Drawing.Point(95, 179);
            this.tbPublisher.Name = "tbPublisher";
            this.tbPublisher.Size = new System.Drawing.Size(158, 31);
            this.tbPublisher.TabIndex = 5;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(10, 23);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(48, 25);
            this.lblTitle.TabIndex = 7;
            this.lblTitle.Text = "Title:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 150);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 25);
            this.label9.TabIndex = 9;
            this.label9.Text = "Publisher:";
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Location = new System.Drawing.Point(12, 80);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(71, 25);
            this.lblAuthor.TabIndex = 8;
            this.lblAuthor.Text = "Author:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(264, 222);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(822, 248);
            this.label11.TabIndex = 4;
            this.label11.Text = resources.GetString("label11.Text");
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1432, 758);
            this.Controls.Add(this.tcAdmin);
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.tcAdmin.ResumeLayout(false);
            this.tpHome.ResumeLayout(false);
            this.tpHome.PerformLayout();
            this.tpPeople.ResumeLayout(false);
            this.tpPeople.PerformLayout();
            this.gbEditInfo.ResumeLayout(false);
            this.gbEditInfo.PerformLayout();
            this.tpRequests.ResumeLayout(false);
            this.gbStatus.ResumeLayout(false);
            this.tpItems.ResumeLayout(false);
            this.tpItems.PerformLayout();
            this.gbEdit.ResumeLayout(false);
            this.gbEdit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tcAdmin;
        private TabPage tpHome;
        private Label lblWelcome;
        private TabPage tpRequests;
        private ListView lvRequests;
        private ComboBox cbStatus;
        private TabPage tpPeople;
        private Button btnSearch;
        private Label lblSearch;
        private TextBox tbSearchU;
        private Label lblOrder;
        private GroupBox gbEditInfo;
        private Label lblRole;
        private ComboBox cbRole;
        private TextBox tbLastName;
        private TextBox tbFirstName;
        private Button btnEdit;
        private TextBox tbAddress;
        private TextBox tbUsername;
        private Label label5;
        private Label label2;
        private Label label4;
        private Label label3;
        private ComboBox cbSortBy;
        private Button btnDelete;
        private Button btnRegister;
        private ListView lvPeople;
        private Button btnLogout;
        private GroupBox gbStatus;
        private Button btnSubmitStatus;
        private TabPage tpItems;
        private ListView lvItems;
        private GroupBox gbEdit;
        private Label label6;
        private ComboBox cbGenre;
        private TextBox tbAuthor;
        private TextBox tbTitle;
        private Button btnEditInfo;
        private TextBox tbPublisher;
        private Label lblTitle;
        private Label label9;
        private Label lblAuthor;
        private Button button1;
        private Label lblSearchItem;
        private TextBox tbSearchTitle;
        private Label label8;
        private ComboBox cbSort;
        private RichTextBox rtbDescription;
        private Label lblDescription;
        private Label label11;
    }
}