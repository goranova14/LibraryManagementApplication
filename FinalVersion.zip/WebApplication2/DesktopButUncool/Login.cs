﻿using LibraryLayer;
using LibraryLayerObjects;
using WebApplication2;

namespace DesktopButUncool
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();

        }

      

        private void btnLogin_Click(object sender, EventArgs e)
        {

            string password = tbPassword.Text;
            string username = tbUsername.Text;

            if (Provider.Container.GetInstance<IPersonManager>().Login(username, password) is Person p)
            {
                if (p.Role.AccessLevel == 100)
                {
                    Menu menu = new();
                    this.Hide();
                    menu.Show();
                }
                if (p.Role.AccessLevel == 50)
                {
                    Manager managerMenu = new();
                    this.Hide();
                    managerMenu.Show();
                }
                else
                {
                    MessageBox.Show("You do not have access to this application.");
                }
            }
            else
            {
                MessageBox.Show("Wrong password or username");
            }
        }
    }
}
