﻿using LibraryBusiness;
using LibraryLayerObjects;

namespace LibraryLayer
{
    public class ItemManager : ManagerBase, IItemManager
    {
        public ItemManager(IDatabase database) : base(database)
        {

        }
        public bool CreateItem(Item item)
        {
            return Database.InsertNewItem(item);

        }
        public List<Item> GetItems()
        {
            return Database.GetItems();
        }
        public Item GetItemByID(Guid id)
        {
            return Database.GetItemByID(id);

        }
        public bool AlterItem(Item item)
        {
            return Database.AlterItem(item);
        }
        public List<Item> GetTop3Requested()
        {
            return Database.GetTop3Requests();
        }
    }
}
