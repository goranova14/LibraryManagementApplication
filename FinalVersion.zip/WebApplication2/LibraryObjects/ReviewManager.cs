﻿using LibraryBusiness;
using LibraryLayerObjects;

namespace LibraryLayer
{
    public class ReviewManager : ManagerBase, IReviewManager
    {
        public ReviewManager(IDatabase database) : base(database)
        {

        }

        public Review GetReview(Guid id)
        {
            return Database.GetReview(id);
        }
        public bool AddReview(Review review)
        {
            return Database.CreateReview(review);
        }


        public bool AlterReview(Review review)
        {
            return Database.AlterReview(review);
        }

        public bool DeleteReview(Review review)
        {
            return Database.DeleteReview(review);
        }

        public List<Review> GetReviews(Guid bookID)
        {
            return Database.GetReviews(bookID);

        }
    }
}
