﻿using LibraryBusiness;

namespace LibraryLayer
{
    public class ManagerBase
    {
        public ManagerBase(IDatabase database)
        {
            Database = database;
        }

        public IDatabase Database { get; }
    }
}