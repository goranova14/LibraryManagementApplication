﻿using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryLayerObjects
{
    public class DVD : Item
    {
        public int Minutes { get; set; }
        public DVD()
        {
            /// <summary>
            /// empty constructor and public set beacuse of model binding
            /// </summary>
        }
        public override string ToString()
        {
            return Minutes.ToString();
        }
       
    }
}
