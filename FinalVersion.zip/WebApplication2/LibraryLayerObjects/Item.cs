﻿using System.ComponentModel.DataAnnotations;
using System.Data;


namespace LibraryLayerObjects
{
    public abstract class Item
    {

        public Item()
        {

        }
        public Item(DataRow dataRow)
        {

            Id = (Guid)dataRow["ID"];
            Author = (String)dataRow["Author"];
            Title = (String)dataRow["Title"];
            Publisher = (String)dataRow["Publisher"];
            Description = (String)dataRow["Description"];
            Genre = (String)dataRow["Genre"];
            Image = (byte[])dataRow["Image"];
        }
        public Guid Id { get; set; }
        [Required(ErrorMessage = "Please enter Author")]
        public string Author { get; set; }
        [Required(ErrorMessage = "Please enter AuthTitle")]

        public string Title { get; set; }
        [Required(ErrorMessage = "Please enter Publisher")]

        public string Publisher { get; set; }
        [Required(ErrorMessage = "Please enter Description")]

        public string Description { get; set; }
        [Required(ErrorMessage = "Please enter Genre")]
        public string Genre { get; set; }

        public byte[] Image { get; set; } = new byte[8];




        public virtual string ToString()
        {
            return Title + Author + Publisher.ToString();
        }
    }
}
