﻿namespace LibraryLayerObjects
{
    public class Request
    {/// <summary>
     /// empty constructor and public set beacuse of model binding
     /// </summary>
        public Request()
        {
                
        }
        public Guid ID { get; set; }
        public Guid PersonID { get; set; }
        public Guid BookID { get; set; }
        public int Quantity { get; set; }
        public bool? Accepted { get; set; }

        public override string ToString()
        {
            return Accepted.ToString();
        }
    }
}
