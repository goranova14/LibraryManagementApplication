﻿namespace LibraryLayerObjects
{
    public class EBook : Book
    {
        public int DPI { get; set; }

        /// <summary>
        /// empty constructor and public set beacuse of model binding
        /// </summary>
        public EBook()
        {

        }
        public override string ToString()
        {
            return base.ToString() + DPI.ToString();
        }

       
    }
}
