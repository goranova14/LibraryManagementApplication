﻿namespace LibraryLayerObjects
{
    public class Review
    {
        public Review()
        {
            /// <summary>
            /// empty constructor and public set beacuse of model binding
            /// </summary>
        }
        public Guid ID { get; set; }
        public Guid PersonID { get; set; }
        public Guid BookID { get; set; }
        public string ReviewText { get; set; }
    }
}
