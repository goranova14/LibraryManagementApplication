﻿namespace LibraryLayerObjects
{
    public class Role
    {
        public Role()
        {
            /// <summary>
            /// empty constructor and public set beacuse of model binding
            /// </summary>
        }
        public Guid ID { get; set; }
        public string Name { get; set; }
        public int AccessLevel { get; set; }
    }
}
